-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2025 at 09:11 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pms`
--

-- --------------------------------------------------------

--
-- Table structure for table `completion_process`
--

CREATE TABLE `completion_process` (
  `id` int(11) NOT NULL,
  `zila_id` bigint(20) DEFAULT NULL,
  `tehsil_id` bigint(20) DEFAULT NULL,
  `moza_id` bigint(20) DEFAULT NULL,
  `employee_id` bigint(20) DEFAULT NULL,
  `completion_process_type_id` int(11) DEFAULT NULL,
  `type_value` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tareekh` date DEFAULT NULL,
  `mizan_khata_dar_khatoni` int(11) DEFAULT NULL,
  `pukhta_khatoni_drandkas_khasra` int(11) DEFAULT NULL,
  `durusti_badrat` int(11) DEFAULT NULL,
  `tehreer_naqal_shajra_nasab` int(11) DEFAULT NULL,
  `tehreer_shajra_nasab_malkan_qabza` int(11) DEFAULT NULL,
  `pukhta_khatajat` int(11) DEFAULT NULL,
  `kham_khatajat_dar_shajra_nasab` int(11) DEFAULT NULL,
  `tehreer_mushtarka_khata` int(11) DEFAULT NULL,
  `pukhta_numberwan_dar_khatoni` int(11) DEFAULT NULL,
  `kham_numberwan_dar_khatoni` int(11) DEFAULT NULL,
  `tasdeeq_akhir` int(11) DEFAULT NULL,
  `mutafarriq_kaam` int(11) DEFAULT NULL,
  `tabsara` text COLLATE utf8mb4_unicode_ci,
  `operator_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `completion_process`
--

INSERT INTO `completion_process` (`id`, `zila_id`, `tehsil_id`, `moza_id`, `employee_id`, `completion_process_type_id`, `type_value`, `tareekh`, `mizan_khata_dar_khatoni`, `pukhta_khatoni_drandkas_khasra`, `durusti_badrat`, `tehreer_naqal_shajra_nasab`, `tehreer_shajra_nasab_malkan_qabza`, `pukhta_khatajat`, `kham_khatajat_dar_shajra_nasab`, `tehreer_mushtarka_khata`, `pukhta_numberwan_dar_khatoni`, `kham_numberwan_dar_khatoni`, `tasdeeq_akhir`, `mutafarriq_kaam`, `tabsara`, `operator_id`, `created_at`) VALUES
(1, 66, 89, 89001, 1, NULL, NULL, '2025-09-24', 200, 34, 67, 5, 56, 22, 22, 22, 22, 22, 22, NULL, NULL, NULL, '2025-09-23 20:14:27'),
(2, 66, 89, 89011, 1, 6, '5', '2025-09-24', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-09-24 10:06:28'),
(3, 67, 91, 91029, 1, 1, '55', '2025-09-24', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-09-24 10:13:16'),
(4, 67, 91, 91029, 1, 1, '44', '2025-09-24', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-09-24 10:40:10');

-- --------------------------------------------------------

--
-- Table structure for table `completion_process_types`
--

CREATE TABLE `completion_process_types` (
  `id` int(11) NOT NULL,
  `title_ur` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `completion_process_types`
--

INSERT INTO `completion_process_types` (`id`, `title_ur`) VALUES
(1, 'میزان کھاتہ دار/کھاتونی'),
(2, 'پختہ کھاتونی درانڈکس خسراہ'),
(3, 'درستی بدراعت'),
(4, 'تحریر نقل شجرہ نسب'),
(5, 'تحریر شجرہ نسب مالکان قبضہ'),
(6, 'پختہ کھاتاجات'),
(7, 'خام کھاتاجات در شجرہ نسب'),
(8, 'تحریر مشترکہ کھاتہ'),
(9, 'پختہ نمبرواں در کھاتونی'),
(10, 'خام نمبرواں در کھاتونی'),
(11, 'تصدیق آخر'),
(12, 'متفرق کام');

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `districtId` int(11) NOT NULL,
  `districtNameEng` varchar(100) DEFAULT NULL,
  `districtNameUrdu` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`districtId`, `districtNameEng`, `districtNameUrdu`) VALUES
(30, 'Swat', 'سوات'),
(66, 'Dir Upper', 'دیر بالا'),
(67, 'Dir Lower', 'دیر پائیں');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `nam` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `walid_ka_nam` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zila_id` bigint(20) DEFAULT NULL,
  `tehsil_id` bigint(20) DEFAULT NULL,
  `moza_id` bigint(20) DEFAULT NULL,
  `pata` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnic` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `darja_taleem` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ahalkar_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tareekh_shamil` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `nam`, `walid_ka_nam`, `zila_id`, `tehsil_id`, `moza_id`, `pata`, `phone`, `cnic`, `darja_taleem`, `ahalkar_type`, `tareekh_shamil`, `created_at`) VALUES
(1, 'یامین خان', 'محمد آمین خان', 66, 80, 80010, 'کوٹکہ میر عالم داودشاہ', '03349077564', '1110130533881', 'ماسٹر ان کمپوٹر', '1', '2025-09-24', '2025-09-24 00:47:20');

-- --------------------------------------------------------

--
-- Table structure for table `employee_type`
--

CREATE TABLE `employee_type` (
  `ahalkar_type_id` int(11) NOT NULL,
  `ahalkar_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_type`
--

INSERT INTO `employee_type` (`ahalkar_type_id`, `ahalkar_title`) VALUES
(1, 'پٹواری'),
(2, 'گرداور'),
(3, 'قانون گوہ');

-- --------------------------------------------------------

--
-- Table structure for table `mozas`
--

CREATE TABLE `mozas` (
  `mozaId` int(11) NOT NULL,
  `tehsilId` int(11) DEFAULT NULL,
  `mozaNameEng` varchar(100) DEFAULT NULL,
  `mozaNameUrdu` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mozas`
--

INSERT INTO `mozas` (`mozaId`, `tehsilId`, `mozaNameEng`, `mozaNameUrdu`) VALUES
(68001, 68, 'Mataltan', 'مٹلتان'),
(68002, 68, 'Ashuron', 'اشورن'),
(68003, 68, 'Shahu', 'شهو'),
(68004, 68, 'Utror', 'اتروڑ'),
(68005, 68, 'Gabral', 'گبرال'),
(68006, 68, 'Bila', 'بیله'),
(68007, 68, 'Kalam', 'کالام'),
(68008, 68, 'Kanai', 'کنئی'),
(68009, 68, 'Gaba', 'جبه'),
(68010, 68, 'Jalbanrh', 'جالبنڑ'),
(68011, 68, 'Ushu', 'اوشو'),
(68012, 68, 'Gorkain', 'گورکین'),
(68013, 68, 'Buyoon', 'بویون'),
(68014, 68, 'Paloga', 'پلوگه'),
(68015, 68, 'Karin', 'کارین'),
(68016, 68, 'Bahan', 'بهان'),
(68017, 68, 'Sazgul', 'سازگل'),
(69001, 69, 'Sheringal', 'شرنگل'),
(69002, 69, 'Jatkot/Goryal', 'جٹکوٹ/گوریال'),
(69003, 69, 'Sahoni', 'سهونی'),
(69004, 69, 'Ganshal', 'گانشال'),
(69005, 69, 'Dun', 'دون'),
(69006, 69, 'Narkun', 'نرکون'),
(69007, 69, 'Kandow', 'کنڈوو'),
(69008, 69, 'Shahur', 'شهور'),
(69009, 69, 'Achar Bala', 'اچاربالا'),
(69010, 69, 'Dogdara Bala', 'ڈوگ دره بالا'),
(69011, 69, 'Dogdara Payeen', 'ڈوگ دره پائین'),
(69012, 69, 'Badarkani', 'بدرکانی'),
(69013, 69, 'Menadog', 'میناڈوگ'),
(69014, 69, 'Shatkas', 'شٹکاس'),
(69015, 69, 'malook khorh', 'ملوک حوڑ'),
(69016, 69, 'Guldi Bella', 'گلدی بیلا'),
(69017, 69, 'Sundri', 'سندری'),
(69018, 69, 'Barkalay', 'برکلے'),
(72001, 72, 'Badwan Bala', 'باڈوان بالا'),
(72002, 72, 'Badwan Payyen', 'باڈوان پائین'),
(72003, 72, 'Trai', 'ترئی'),
(72004, 72, 'Mia Brangola', 'میاں بڑنگولہ'),
(72005, 72, 'Khadagzai Bala', 'خادگزئی بالا'),
(72006, 72, 'Khadakzai Payyen', 'خادگزئی پائین'),
(72007, 72, 'Kamala', 'کمالا'),
(72008, 72, 'Asbanrr Bazar', 'اسنبڑ بازار'),
(72009, 72, 'Dheran', 'دھیران'),
(72010, 72, 'Mesyalowarr', 'میسیا لوّڑ'),
(72011, 72, 'Kumbarr', 'کومبڑ'),
(72012, 72, 'Utala', 'اوٹالا'),
(72013, 72, 'Asbanrr Dheri', 'اسنبڑ ڈھیری'),
(72014, 72, 'Kashmir', 'کشمیر'),
(72015, 72, 'Bambolai', 'بمبولئی'),
(72016, 72, 'Ramorra', 'راموڑا'),
(72017, 72, 'Sehsada', 'سه سده'),
(72018, 72, 'Darra', 'درّه'),
(72019, 72, 'Barrorhay', 'باروڑی'),
(72020, 72, 'Taza Gram', 'تازه گرام'),
(72021, 72, 'Shawa', 'شوہ'),
(72022, 72, 'Kittiarri', 'کیٹیاڑی'),
(72023, 72, 'Khanpur', 'خان پور'),
(72024, 72, 'Teknai', 'ٹکنئی'),
(72025, 72, 'Sia', 'سیا'),
(72026, 72, 'Avi Shah', 'اوی  شاه'),
(72027, 72, 'Tarno', 'ترنو'),
(72028, 72, 'Bochakai', 'بوچکے'),
(72029, 72, 'Chakdara', 'چکدره'),
(72030, 72, 'Bagh Kandai', 'باغ کندئی'),
(72031, 72, 'Gadar', 'گدر'),
(72032, 72, 'Tindo Daag', 'تیندوڈاگ'),
(72033, 72, 'Osakai', 'اوساکئی'),
(72034, 72, 'Warsak', 'ورسک'),
(72035, 72, 'Safrona', 'سافرونه'),
(72036, 72, 'Ouch Sharqi', 'اوچ شرقی'),
(72037, 72, 'Ouch Gharbi', 'اوچ غربی'),
(72038, 72, 'Shahabad', 'شاه آباد'),
(72039, 72, 'Kotigram', 'کوٹی گرام'),
(72040, 72, 'Khairabad', 'خیر آباد'),
(72041, 72, 'Dheri', 'ڈھیری'),
(72042, 72, 'Chekho', 'چیخو'),
(72043, 72, 'Shorshang', 'شوڑشنگ'),
(72044, 72, 'Bagh', 'باغ'),
(72045, 72, 'Hamza Banda', 'حمزه بانڈه'),
(72046, 72, 'Bremkay', 'بریمکے'),
(72047, 72, 'Tiknai Payeen', 'تیکنائی پائین'),
(72048, 72, 'Teknai Bala', 'ٹکنئی بالا'),
(73001, 73, 'Timergara', 'تیمرگره'),
(73002, 73, 'Khungi', 'هونگی'),
(73003, 73, 'Shekawlai', 'شیکاولائی'),
(73004, 73, 'Paito Dara', 'پیٹو دره'),
(73005, 73, 'Danwa', 'دانوه'),
(73006, 73, 'Siar Darra', 'سیار دره'),
(73007, 91, 'Bajawro', 'باجاوڑو'),
(73008, 73, 'Qillagai', 'قلاگئی'),
(73009, 91, 'Nasafa', 'ناسافه'),
(73010, 91, 'Sarai Bala', 'سرائے بالا'),
(73011, 91, 'Sarai Payeen', 'سرائے پائین'),
(73012, 91, 'Amlook Dara', 'املوک داره'),
(73013, 91, 'Macho', 'ماچو'),
(73014, 91, 'Ziarat Talash', 'زیارت تلاش'),
(73015, 91, 'Pingal', 'پینگال'),
(73016, 91, 'Katon Bala', 'کتون بالا'),
(73017, 91, 'Tauda Chena', 'توده چینه'),
(73018, 91, 'Dheri Shamshi Khan', 'دھیری شمسی حان'),
(73019, 91, 'Khadang', 'خدنگ'),
(73020, 91, 'Bakht Bilanda', 'بخت بلندا'),
(73021, 73, 'Saddo', 'سدو'),
(73022, 91, 'Bandagai', 'بندگئی'),
(73023, 91, 'Chinarona', 'چنارونه'),
(73024, 91, 'Shamshi Khan', 'شمسی حان'),
(73025, 91, 'Gumbat', 'گمبٹ'),
(73026, 91, 'Gero', 'گیرو'),
(73027, 91, 'Utala', 'اٹالا'),
(73028, 91, 'Bagh', 'باغ'),
(74001, 74, 'Rabat', 'رباط'),
(74002, 74, 'Rani', 'رانی'),
(74003, 74, 'Baroon', 'بارون'),
(74004, 74, 'Oodigram', 'اودیگرام'),
(74005, 74, 'Shehzadi', 'شهزادی'),
(74006, 74, 'Munjai', 'منجائی'),
(74007, 74, 'Manzary Tangi', 'منزاری تنگی'),
(74008, 74, 'Lajbok', 'لاجبوک'),
(74009, 74, 'Sar Banda', 'سر بانڈه'),
(74010, 74, 'Kandaroo No 2', 'کنڈرو نمبر 2'),
(74011, 74, 'Dermal Bala', 'درمال بالا'),
(74012, 74, 'Biyarai', 'بیارائی'),
(74013, 74, 'Kori', 'کوری'),
(74014, 74, 'Dermal Payeen', 'درمال پائین'),
(74015, 74, 'Naray Tangi', 'نرائے تنگی'),
(74016, 74, 'Shakoo', 'شاکو'),
(74017, 74, 'Mano Banda', 'مانو بانڈه'),
(74018, 74, 'Rehan Pur', 'ریحان پور'),
(74019, 74, 'Ghero Tangi', 'غیرو تنگی'),
(74020, 74, 'Moranai', 'مورنئی'),
(74021, 74, 'Haya Serai', 'حایا سرائی'),
(74022, 74, 'Shah Bandi', 'شاه بانڈی'),
(74023, 74, 'Qamar Kotkay', 'قمر کوٹکے'),
(74024, 74, 'Koto', 'کوٹو'),
(74025, 74, 'Misl Khani', 'مثل خانی'),
(74026, 74, 'Sangwalai', 'سنگ والئی'),
(74027, 74, 'Taboo', 'تا بو'),
(74028, 74, 'Kala Dak', 'کالا ڈاک'),
(74029, 74, 'Shakar Tangi', 'شکر تنگی'),
(74030, 74, 'Qila Gay', 'قلعه گئی'),
(74031, 74, 'Malakand Bala', 'مالاکنڈ بالا'),
(74032, 74, 'Malakand Payeen', 'مالاکنڈ پائین'),
(74033, 74, 'Shati', 'شاٹی'),
(74034, 74, 'Haji Abad', 'حاجی آباد'),
(74035, 74, 'Koto', 'کوٹو'),
(74036, 74, 'Andehraiy', 'اندھیرائّی'),
(74037, 74, 'Khema', 'خیمه'),
(74038, 74, 'Malakabad chargory', 'ملک آباد چرگوڑئی'),
(74039, 74, 'Kandaro', 'کنڈرو'),
(74040, 74, 'kadh', 'کڈھ'),
(74041, 74, 'Wah Tangi', 'واہ تنگی'),
(74042, 74, 'Gero', 'گیرو'),
(75001, 75, 'Khall', 'خال'),
(75002, 75, 'Shalfalam', 'شالفلام'),
(75003, 75, 'Malikabad', 'ملک آباد'),
(75004, 75, 'Adai', 'اڈئی'),
(75005, 75, 'Tormang', 'تور منگ'),
(75006, 75, 'Tormang-1', 'تور منگ-1'),
(75007, 75, 'Tormang-2', 'تورمنگ-2'),
(75008, 75, 'Luqman Banda', 'لقمان بانڈه'),
(75009, 75, 'Adokay', 'اڈوکے'),
(75010, 75, 'Galkorr', 'گلکوڑ'),
(75011, 75, 'Safaray', 'سفارے'),
(75012, 75, 'Sairay', 'سئیرے'),
(76001, 76, 'Lal Qila', 'لال قلعه'),
(76002, 76, 'Manyal', 'مانیال'),
(76003, 76, 'Burai', 'بورائی'),
(76004, 76, 'Gul Abad', 'گل آباد'),
(76005, 76, 'Namazkot', 'نمازکوٹ'),
(76006, 76, 'Safray', 'سفرے'),
(76007, 76, 'Zaanai', 'زانئی'),
(76008, 76, 'Tawso', 'تاوسو'),
(76009, 76, 'Kotkay Bala', 'کوٹکے بالا'),
(76010, 76, 'Kotkay payeen', 'کوٹکے پائین'),
(76011, 76, 'Chinarkot', 'چنارکوٹ'),
(76012, 76, 'Chalgazay', 'چلغازے'),
(76013, 76, 'Shand Inzar', 'شانڈانزار'),
(76014, 76, 'Shadass Bala', 'شداس بالا'),
(76015, 76, 'Barjo Ghat', 'برجو گٹ'),
(76016, 76, 'Shadass Payeen', 'شداس پائین'),
(76017, 76, 'Mullayanu Banda', 'ملایانو بانڈه'),
(76018, 76, 'Dokrrai Bala', 'دوکڑی بالا'),
(76019, 76, 'Dokrrai Payeen', 'دوکڑی پائین'),
(76020, 76, 'Gallgot', 'گالگوت'),
(76021, 76, 'Kooru Bagh', 'کورو باغ'),
(76022, 76, 'Gumbatay', 'گمبتے'),
(76023, 76, 'Daroo', 'دارو'),
(76024, 76, 'Beshgram', 'بیشگرام'),
(76025, 76, 'Machla', 'ماچله'),
(76026, 76, 'Gumbat Banda', 'گمبت بانڈه'),
(76027, 76, 'Markhanai', 'مرحنئی'),
(76028, 76, 'Bagh', 'باغ'),
(76029, 76, 'Dalgram', 'دلگرام'),
(76030, 76, 'Khazana', 'خزانه'),
(76031, 76, 'Gal', 'گل'),
(76032, 76, 'Bairragam', 'بیڑاگام'),
(76033, 76, 'Berragram', 'بیڑاگرام'),
(76034, 76, 'Karin', 'کارین'),
(76035, 76, 'Mirgam', 'میرگام'),
(76036, 76, 'Nagotal', 'ناگوتل'),
(76037, 76, 'Gorr', 'گوڑ'),
(76038, 76, 'Banday', 'بانڈی'),
(76039, 76, 'Soori Paw', 'سوری پاٶں'),
(76040, 76, 'Barhanay', 'برخانے'),
(77001, 77, 'Bazarak', 'بزارک'),
(77002, 77, 'Tor Qila', 'تور قلعه'),
(77003, 77, 'Areef', 'عریف'),
(77004, 77, 'Mia Kalay', 'میاں کلے'),
(77005, 77, 'Bunrr', 'بنڑ'),
(77006, 77, 'Badalzo', 'بدل زو'),
(77007, 77, 'Munda', 'منڈه'),
(77008, 77, 'Takoro', 'ٹاکورو'),
(77009, 77, 'Khuna Pekat', 'خونه پیکٹ'),
(77010, 77, 'Musa abad', 'موسی اباد'),
(77011, 77, 'Shalkandai', 'شالکنڈائی'),
(77012, 77, 'Gudar Bakro', 'گودر بکرو'),
(77013, 77, 'Khazana', 'خزانه'),
(77014, 77, 'Malala Kotkay', 'ملاله کوٹکے'),
(77015, 77, 'Paloso Dag', 'پالوسو ڈاگ'),
(77016, 77, 'Gharrha', 'گرڑه'),
(77017, 77, 'Gosam', 'گوسم'),
(77018, 77, 'Makhai', 'ماخئ'),
(77019, 77, 'Malala', 'ملاله'),
(77020, 77, 'namaloom', 'نا معلوم'),
(77021, 77, 'Rahim Abad Gardha', 'رحیم اباد گرڑہ'),
(77022, 77, 'Manogay', 'مانوگئی'),
(77023, 77, 'Ghanam Shah', 'غنم شاه'),
(78001, 78, 'Samar Bagh', 'ثمر باغ'),
(78002, 78, 'New Koto', 'نیو کوٹو'),
(78003, 78, 'Raheem Abad', 'رحیم آباد'),
(78004, 78, 'Ghwarra Banda', 'غواڑا بانڈا'),
(78005, 78, 'Shunttalai', 'شونٹلئی'),
(78006, 78, 'Sheena', 'شینه'),
(78007, 78, 'Swara Ghundai', 'سورہ غونڈی'),
(78008, 78, 'Sadbar Kalay', 'صدبر کلے'),
(78009, 78, 'Qandaray', 'قندهارے'),
(78010, 78, 'Mayar', 'میّر'),
(78011, 78, 'Juni Kalay', 'جونی کلے'),
(78012, 78, 'Kotki Shahikhel', 'کوٹکی شاهی خیل'),
(78013, 78, 'Gumbir Shahi Khel', 'گمبیر شاهی خیل'),
(78014, 78, 'Kakass', 'کاکس'),
(78015, 78, 'Kharkay', 'خرکے'),
(78016, 78, 'Maskhenay', 'مسکینی'),
(78017, 78, 'Kullalan', 'کولالان'),
(78018, 78, 'Sangi Para', 'سنگی پارا'),
(78019, 78, 'Tangi Bala', 'تنگی بالا'),
(78020, 78, 'Bokrai', 'بوکرئی'),
(78021, 78, 'Kambat', 'کمبت'),
(78022, 78, 'Leekor', 'لیکور'),
(78023, 78, 'Dinjarai', 'ڈینجا رئی'),
(78024, 78, 'Balooda', 'بالودا'),
(78025, 78, 'Gawardesh', 'گاوردیش'),
(78026, 78, 'Sharbannai', 'شربنّئ'),
(78027, 78, 'Marhai', 'ما نڑئی'),
(78028, 78, 'Shahi/ Bin Shahi', 'شاهی/بن شاهی'),
(78029, 78, 'Meyaar', 'معیار'),
(78030, 78, 'Badeen', 'بادین'),
(79001, 79, 'Wari', 'واڑی'),
(79002, 79, 'Shang', 'شنگ'),
(79003, 79, 'kakd', 'کاکد'),
(79004, 79, 'Diskoor', 'ڈسکور'),
(79005, 79, 'Malook Banda', 'ملک بانڈه'),
(79006, 79, 'Akhagram', 'اهگرام'),
(79007, 79, 'khonanotanga', 'حونانو تنگے'),
(79008, 79, 'Gullibagh', 'گلی باغ'),
(79009, 79, 'batankarkabnj', 'بتن کارکا بنج'),
(79010, 79, 'Pashata', 'پاشاته'),
(79011, 79, 'Balkor', 'بالکور'),
(79012, 79, 'Shagi', 'شاگی'),
(79013, 79, 'Hazara', 'هزاره'),
(79014, 79, 'Nihag', 'نهاگ'),
(79015, 79, 'Shalgha', 'شالگاه'),
(79016, 79, 'Galkgoor', 'گالک گور'),
(79017, 79, 'Karpat', 'کارپت'),
(79018, 79, 'Badali', 'بدالی'),
(79019, 79, 'Mattar', 'متار'),
(79020, 79, 'Bandi', 'بندی'),
(79021, 79, 'Dislawar', 'ڈسلوار'),
(79022, 79, 'Dogram', 'ڈوگرام'),
(79023, 79, 'Ossori Dara', 'اوسوری دره'),
(79024, 79, 'Kadikhel', 'کدی خیل'),
(79025, 79, 'charkum', 'چرکم'),
(79026, 79, 'Sundal', 'صندل'),
(79027, 79, 'Gogyal', 'گوگیال'),
(79028, 79, 'Rambeyal', 'رمبیال'),
(79029, 79, 'Serri', 'سری'),
(79030, 79, 'Nihag Dara', 'نهاگ دره'),
(79031, 79, 'kotka', 'کوٹکه'),
(79032, 79, 'Mullovi', 'مولووی'),
(79033, 79, 'Serri Sultan Khel', 'سری سلطان خیل'),
(79034, 79, 'Patawo', 'پٹاوو'),
(79035, 79, 'Chaper', 'چاپر'),
(79036, 79, 'Babo Kalay', 'بابوکلے'),
(79037, 79, 'Nasirabad', 'ناصر آباد'),
(79038, 79, 'Jellar', 'جیلر'),
(80001, 80, 'Kas', 'کس'),
(80002, 80, 'Now', 'نوو'),
(80003, 80, 'Show', 'شاٶ'),
(80004, 80, 'Rehankot', 'ریحان کوٹ'),
(80005, 80, 'Panakot', 'پاناکوٹ'),
(80006, 80, 'Hayaga', 'حیاگے'),
(80007, 80, 'Qulandi', 'قلندی'),
(80008, 80, 'Dubando', 'ڈوبندو'),
(80009, 80, 'Bagh Kali/ sarkd', 'باغ کلی/ سرکد'),
(80010, 80, 'Chukyatten', 'چکیاتن'),
(80011, 80, 'Serrati', 'سیراتی'),
(80012, 80, 'Kotka', 'کوٹکه'),
(80013, 80, 'Chargalli', 'چرگلی'),
(80014, 80, 'Ganorhi', 'گنوڑی'),
(80015, 80, 'Serbat', 'سیربت'),
(80016, 80, 'Pacha kalay', 'پاچه کلے'),
(80017, 80, 'hatan', 'ھاتن'),
(88001, 88, 'Darorha', 'داروڑه'),
(88002, 88, 'Gandigar', 'گندی گڑ'),
(88003, 88, 'Katton Payeen', 'کاٹن پائین'),
(88004, 88, 'Bibyawar', 'بیبیاور'),
(88005, 88, 'Shamorhghar', 'شموڑگار'),
(88006, 88, 'Serri', 'سیری'),
(88007, 88, 'Kher Dara', 'خیر دره'),
(88008, 88, 'Jabar', 'جبر'),
(88009, 88, 'Katton Bala', 'کاٹن بالا'),
(88010, 88, 'Nishan Banda', 'نشان بانڈه'),
(88011, 88, 'Daam', 'دام'),
(88012, 88, 'Tarpatar', 'ترپتر'),
(88013, 88, 'Alamas', 'الماس'),
(88014, 88, 'Sadiqa Banda', 'صدیقه بانڈه'),
(88015, 88, 'Palam', 'پلام'),
(88016, 88, 'Samkot', 'سمکوٹ'),
(88017, 88, 'Barkand', 'برکنڈ'),
(88018, 88, 'Garkor', 'گلکوڑ'),
(88019, 88, 'Ali Gasar', 'علی گاسر'),
(88020, 88, 'Jabbi', 'جبی'),
(89001, 89, 'Barawal bandi', 'براول بانڈی'),
(89002, 89, 'Chinarkot', 'چنار کوٹ'),
(89003, 89, 'Sundrawal', 'سندراوال'),
(89004, 89, 'DirKhan', 'دیرخان'),
(89005, 89, 'Darhi Kund', 'داڑی کند'),
(89006, 89, 'Shangarra', 'شنگاڑه'),
(89007, 89, 'GullBahar', 'گل بهار'),
(89008, 89, 'Shahi Kot', 'شاهی کوٹ'),
(89009, 89, 'Shaltalo', 'شلتالو'),
(89010, 89, 'Nasrat darra', 'نصرت دره'),
(89011, 89, 'Bend', 'بیند'),
(89012, 89, 'Janbatti', 'جان بٹی'),
(89013, 89, 'Noor Khel', 'نورخیل'),
(90001, 90, 'Patrak', 'پاتراک'),
(90002, 90, 'Pesherak', 'پیشیراک'),
(90003, 90, 'Besho', 'بیشو'),
(90004, 90, 'Medan', 'میدان'),
(90005, 90, 'Shingga', 'شونگا'),
(90006, 90, 'Seyasan', 'سیاسن'),
(90007, 90, 'Bari Kot', 'بریکوٹ'),
(90008, 90, 'Beyarh', 'بیاڑ'),
(90009, 90, 'Junkas', 'جنکاس'),
(90010, 90, 'Shalben', 'شلبین'),
(90011, 90, 'Delatoorkas', 'دیلاتورکاس'),
(90012, 90, 'Tall', 'تال'),
(90013, 90, 'Lamutte', 'لموتے'),
(90014, 90, 'Haji Shai', 'حاجی شئی'),
(90015, 90, 'Kumrat', 'کمراٹ'),
(91029, 91, 'Ajoo', 'اجو'),
(91030, 91, 'Kamangara', 'کمانگره'),
(91031, 91, 'Banda', 'بانڈه'),
(91032, 91, 'Tangay', 'تنگئی'),
(91033, 91, 'Nagri Bala', 'نگری بالا'),
(91034, 91, 'Nagri Payeen', 'نگری پائین'),
(91035, 91, 'Daramdal', 'درامدال');

-- --------------------------------------------------------

--
-- Table structure for table `operators`
--

CREATE TABLE `operators` (
  `id` int(11) NOT NULL,
  `zila_id` bigint(20) NOT NULL,
  `tehsil_id` bigint(20) NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `operators`
--

INSERT INTO `operators` (`id`, `zila_id`, `tehsil_id`, `username`, `password`, `full_name`, `role_id`, `created_at`) VALUES
(1, 67, 77, 'yaminkhanmcs@gmail.com', '1234567', 'یامین خان', 1, '2025-09-23 07:57:37');

-- --------------------------------------------------------

--
-- Table structure for table `partal`
--

CREATE TABLE `partal` (
  `id` int(11) NOT NULL,
  `zila_nam` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tehsil_nam` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moza_nam` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `patwari_nam` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ahalkar_nam` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tareekh_partal` date DEFAULT NULL,
  `tasdeeq_milkiat_pemuda_khasra` int(11) DEFAULT NULL,
  `tasdeeq_milkiat_pemuda_khasra_badrat` int(11) DEFAULT NULL,
  `tasdeeq_milkiat_qabza_kasht_khasra` int(11) DEFAULT NULL,
  `tasdeeq_milkiat_qabza_kasht_badrat` int(11) DEFAULT NULL,
  `tasdeeq_shajra_nasab_guri` int(11) DEFAULT NULL,
  `tasdeeq_shajra_nasab_badrat` int(11) DEFAULT NULL,
  `muqabala_khatoni_chomanda` int(11) DEFAULT NULL,
  `muqabala_khatoni_chomanda_badrat` int(11) DEFAULT NULL,
  `tabsara` text COLLATE utf8mb4_unicode_ci,
  `operator_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `partal`
--

INSERT INTO `partal` (`id`, `zila_nam`, `tehsil_nam`, `moza_nam`, `patwari_nam`, `ahalkar_nam`, `tareekh_partal`, `tasdeeq_milkiat_pemuda_khasra`, `tasdeeq_milkiat_pemuda_khasra_badrat`, `tasdeeq_milkiat_qabza_kasht_khasra`, `tasdeeq_milkiat_qabza_kasht_badrat`, `tasdeeq_shajra_nasab_guri`, `tasdeeq_shajra_nasab_badrat`, `muqabala_khatoni_chomanda`, `muqabala_khatoni_chomanda_badrat`, `tabsara`, `operator_id`, `created_at`) VALUES
(1, '66', '89', '89012', 'یامین خان', 'یامین خان', '2025-09-25', 5, 7, 4, 11, 22, 33, 34, 2, NULL, NULL, '2025-09-25 05:48:00');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `title`) VALUES
(1, 'Admin'),
(2, 'Computer Operator');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `logo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_text` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `logo_path`, `footer_text`, `created_at`, `updated_at`) VALUES
(1, 'storage/logo/N9BJ3SfDFan2Opyc8cVzfoyMnF6ExMe1r4l81ikz.png', 'پروگریس پورٹل سیٹلمینٹ اف لینڈ ریکارڈز دیر کلام خیبر پختونحواہ', '2025-09-23 10:38:23', '2025-09-26 05:53:01');

-- --------------------------------------------------------

--
-- Table structure for table `tehsils`
--

CREATE TABLE `tehsils` (
  `tehsilId` int(11) NOT NULL,
  `districtId` int(11) DEFAULT NULL,
  `tehsilNameEng` varchar(100) DEFAULT NULL,
  `tehsilNameUrdu` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tehsils`
--

INSERT INTO `tehsils` (`tehsilId`, `districtId`, `tehsilNameEng`, `tehsilNameUrdu`) VALUES
(68, 30, 'Kalam', 'کالام'),
(69, 66, 'Sherangal', 'شیرنگل'),
(72, 67, 'Adenzai', 'ادینزئی'),
(73, 67, 'Timergara', 'تیمر گرہ'),
(74, 67, 'Balambat', 'بلامبٹ'),
(75, 67, 'Khall', 'خال'),
(76, 67, 'Lal Qila', 'لال قلعہ'),
(77, 67, 'Munda', 'منڈہ'),
(78, 67, 'Samar Bagh', 'ثمر باغ'),
(79, 66, 'Wari', 'واڑی'),
(80, 66, 'Dir Khas', 'دیر حاص'),
(88, 66, 'Larjam', 'لرجم'),
(89, 66, 'Barawal', 'براول'),
(90, 66, 'Kalkot', 'کالکوٹ'),
(91, 67, 'Talash', 'تالاش');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `completion_process`
--
ALTER TABLE `completion_process`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_completion_process_type_id` (`completion_process_type_id`);

--
-- Indexes for table `completion_process_types`
--
ALTER TABLE `completion_process_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`districtId`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_type`
--
ALTER TABLE `employee_type`
  ADD PRIMARY KEY (`ahalkar_type_id`);

--
-- Indexes for table `mozas`
--
ALTER TABLE `mozas`
  ADD PRIMARY KEY (`mozaId`);

--
-- Indexes for table `operators`
--
ALTER TABLE `operators`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `partal`
--
ALTER TABLE `partal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tehsils`
--
ALTER TABLE `tehsils`
  ADD PRIMARY KEY (`tehsilId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `completion_process`
--
ALTER TABLE `completion_process`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `completion_process_types`
--
ALTER TABLE `completion_process_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employee_type`
--
ALTER TABLE `employee_type`
  MODIFY `ahalkar_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `operators`
--
ALTER TABLE `operators`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `partal`
--
ALTER TABLE `partal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
