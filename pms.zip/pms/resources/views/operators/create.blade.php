
@extends('layouts.app')

@section('title', 'نیا صارف شامل کریں')

@section('content')
<div class="container" >
    <center><legend><h3>نیا صارف شامل کریں</h3></legend></center>
    <form action="{{ route('operators.store') }}" method="POST" class="form-modern" >
        @csrf
        <div class="row">
           
           
            
            <div class="form-group col-md-4 col-12">
                <label>مکمل نام</label>
                <input type="text" name="full_name" class="form-control" required>
            </div>
             <div class="form-group col-md-4 col-12">
                <label>صارف نام</label>
                <input type="text" name="username" class="form-control" required>
            </div>
             <div class="form-group col-md-4 col-12">
                <label>پاس ورڈ</label>
                <input type="password" name="password" class="form-control" required>
            </div>
        </div>
        <div class="row">
             <div class="form-group col-md-6 col-12">
                <label>ضلع</label>
                <select name="zila_id" id="zila_id" class="form-control" required onchange="onDistrictChange(this.value, 'tehsil_id')">
                    <option value="">منتخب کریں</option>
                </select>
            </div>
            <div class="form-group col-md-6 col-12">
                <label>تحصیل</label>
                <select name="tehsil_id" id="tehsil_id" class="form-control" required>
                    <option value="">منتخب کریں</option>
                </select>
            </div>
           
        </div>
        
        <div class="row">
            <div class="form-group col-md-6 col-xs-12">
                <label class="control-label" style="float: right; text-align: right;">رول</label>
                <select name="role_id" class="form-control" style="direction: rtl; text-align: right;">
                    <option value="">منتخب کریں</option>
                    @foreach($roles as $role)
                        <option value="{{ $role->role_id }}">{{ $role->title }}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <br>
        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> محفوظ کریں</button>
        <a href="{{ route('operators.index') }}" class="btn btn-secondary">واپس</a>
    </form>
</div>
@endsection
