<footer class="footer text-center">
    <p>&copy; {{ date('Y') }} Progress Management System</p>
</footer>
