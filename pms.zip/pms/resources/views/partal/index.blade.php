@extends('layouts.app')

@section('title', 'پڑتال ریکارڈ')

@section('content')
<div class="container" dir="rtl">
    <style>
        thead th {
            border:1px solid #ddd8d8 !important;
        }
        @media print { .no-print { display: none; } }
    </style>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="{{ route('partal.create') }}" class="btn btn-success">
            <i class="fa fa-plus"></i> نیا ریکارڈ شامل کریں
        </a>
        <center><h3 class="mb-0">گوشوارہ پڑتال رپورٹ</h3></center>
    </div>

    <div class="table-responsive">
        <table class="table table-striped table-hover table-bordered text-center">
            <thead class="thead-dark">
                <tr>
                    <th rowspan="2">سیریل نمبر</th>
                    <th colspan="6">بنیادی معلومات</th>
                    <th colspan="2">پڑتال پیمائش موقع</th>
                    <th colspan="2">تصدیق آخیر ملکیت وغیرہ بر موقع</th>
                    <th colspan="2">تصدیق آخیر شجرہ نسب</th>
                    <th colspan="2">تصدیق ملکیت و قبضہ کاشت وغیرہ</th>
                    <th rowspan="2">تبصرہ</th>
                    <th rowspan="2">عمل</th>
                </tr>
                <tr>
                    <th>ضلع نام</th>
                    <th>تحصیل نام</th>
                    <th>موضع نام</th>
                    <th>پٹواری نام</th>
                    <th>اہلکار نام</th>
                    <th>تاریخ پڑتال</th>
                    <th>تصدیق ملکیت/پیمود شدہ نمبرات خسرہ</th>
                    <th>تعداد برامدہ بدرات</th>
                    <th>تصدیق ملکیت و قبضہ کاشت نمبرات خسرہ</th>
                    <th>تعداد برامدہ بدرات</th>
                    <th>تعداد گھری</th>
                    <th>تعداد برامدہ بدرات</th>
                    <th>مقابلہ کھتونی ہمراہ کاپی چومنڈہ</th>
                    <th>تعداد برامدہ بدرات</th>
                </tr>
            </thead>
            <tbody>
                @foreach($records as $rec)
                <tr>
                    <td>{{ $rec->id }}</td>
                    <td>{{ $rec->districtNameUrdu }}</td>
                    <td>{{ $rec->tehsilNameUrdu }}</td>
                    <td>{{ $rec->mozaNameUrdu }}</td>
                    <td>{{ $rec->patwari_nam }} {{ $rec->patwari_title }}</td>
                    <td>{{ $rec->ahalkar_nam }} {{ $rec->ahalkar_title }}</td>
                    <td class="date-cell">{{ $rec->tareekh_partal ? date('d-m-Y', strtotime($rec->tareekh_partal)) : '' }}</td>
                    <td>{{ $rec->tasdeeq_milkiat_pemuda_khasra }}</td>
                    <td>{{ $rec->tasdeeq_milkiat_pemuda_khasra_badrat }}</td>
                    <td>{{ $rec->tasdeeq_milkiat_qabza_kasht_khasra }}</td>
                    <td>{{ $rec->tasdeeq_milkiat_qabza_kasht_badrat }}</td>
                    <td>{{ $rec->tasdeeq_shajra_nasab_guri }}</td>
                    <td>{{ $rec->tasdeeq_shajra_nasab_badrat }}</td>
                    <td>{{ $rec->muqabala_khatoni_chomanda }}</td>
                    <td>{{ $rec->muqabala_khatoni_chomanda_badrat }}</td>
                    <td>{{ $rec->tabsara }}</td>
                    <td>
                        <a href="{{ route('partal.edit', $rec->id) }}" class="btn btn-sm btn-warning">
                            <i class="fa fa-edit"></i> ترمیم
                        </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        <div class="d-flex justify-content-center">
            {{ $records->links() }}
        </div>
    </div>
</div>
@endsection
