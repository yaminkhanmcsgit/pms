@extends('layouts.app')

@section('title', 'ڈیش بورڈ')

@section('content')
<div class="container " dir="rtl" >
   
    <div class=" dashboard-panels" style="display: flex !important; justify-content: space-around;">
        <div style="flex: 1; margin: 5px;">
            <div class="panel panel-success">
                <div class="panel-heading">صارفین</div>
                <div class="panel-body text-center">
                    <a href="{{ route('operators.index') }}" class="btn btn-success">صارفین دیکھیں</a>
                </div>
            </div>
        </div>
        <div style="flex: 1; margin: 5px;">
            <div class="panel panel-info">
                <div class="panel-heading">ملازمین</div>
                <div class="panel-body text-center">
                    <a href="{{ route('employees.index') }}" class="btn btn-primary">ملازمین دیکھیں</a>
                </div>
            </div>
        </div>
        <div style="flex: 1; margin: 5px;">
            <div class="panel panel-warning">
                <div class="panel-heading">تکمیلی عمل</div>
                <div class="panel-body text-center">
                    <a href="{{ route('completion_process.index') }}" class="btn btn-warning">تکمیلی عمل دیکھیں</a>
                </div>
            </div>
        </div>
        <div style="flex: 1; margin: 5px;">
            <div class="panel panel-danger">
                <div class="panel-heading">پڑتال</div>
                <div class="panel-body text-center">
                    <a href="{{ route('partal.index') }}" class="btn btn-danger">پڑتال دیکھیں</a>
                </div>
            </div>
        </div>
        <div style="flex: 1; margin: 5px;">
            <div class="panel panel-default">
                <div class="panel-heading">ترتیبات</div>
                <div class="panel-body text-center">
                    <a href="{{ route('settings.edit') }}" class="btn btn-default">ترتیبات دیکھیں</a>
                </div>
            </div>
        </div>
    </div>
    <!-- گوشوارہ پڑتال رپورٹ section with table -->
    <div>
        <div class="">
            <style>
                .dashboard-header { text-align: center; margin: 30px 0 20px 0; padding: 15px; background: #f7f7f7; color: #333; border-radius: 5px; border: 1px solid #e0e0e0; }
                .report-container { padding: 10px 0 0 0; border-radius: 0; box-shadow: none; margin-bottom: 20px; background: none; }
                table { width: 100%; border-collapse: collapse; margin: 15px 0; font-size: 14px; }
                table th, table td { border: 1px solid #ddd; padding: 10px; text-align: center; }
                table th { background-color: #e9ecef; color: #333; font-weight: bold; }
                tr:nth-child(even) { background-color: #f9f9f9; }
                tr:nth-child(odd) { background-color: #fff; }
                tr:hover { background-color: #f1f1f1; }
                .filter-form { margin-bottom: 20px; }
                .value-cell { background-color: #d4edda !important; }
            </style>
            <form method="GET" action="{{ route('dashboard') }}" class="filter-form form-inline text-right">
                <div class="form-group">
                    <label for="district_id">ضلع:</label>
                    <select name="district_id" id="district_id" class="form-control">
                        <option value="">تمام</option>
                        @foreach($districts as $d)
                            <option value="{{ $d->districtNameUrdu }}" {{ (request('district_id') == $d->districtNameUrdu) ? 'selected' : '' }}>{{ $d->districtNameUrdu }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="tehsil_id">تحصیل:</label>
                    <select name="tehsil_id" id="tehsil_id" class="form-control">
                        <option value="">تمام</option>
                        @foreach($tehsils as $t)
                            <option value="{{ $t->tehsilNameUrdu }}" {{ (request('tehsil_id') == $t->tehsilNameUrdu) ? 'selected' : '' }}>{{ $t->tehsilNameUrdu }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label for="from_date">از تاریخ:</label>
                    <input type="date" name="from_date" id="from_date" class="form-control" value="{{ $from_date ?? '' }}">
                </div>
                <div class="form-group">
                    <label for="to_date">تا تاریخ:</label>
                    <input type="date" name="to_date" id="to_date" class="form-control" value="{{ $to_date ?? '' }}">
                </div>
                <button type="submit" class="btn btn-info">فلٹر کریں</button>
            </form>
            <div class="dashboard-header">
             <h3>گوشوارہ پڑتال خلاصہ ({{ $from_date ? date('d-m-Y', strtotime($from_date)) : '' }} تا {{ $to_date ? date('d-m-Y', strtotime($to_date)) : '' }})</h3>
            </div>
            <div class="report-container">
                <table id="reportTable">
                    <thead>
                        <tr>
                            <th rowspan="2">سیریل نمبر</th>
                            <th colspan="7">بنیادی معلومات</th>
                            <th colspan="2">پڑتال پیمائش موقع</th>
                            <th colspan="2">تصدیق آخیر ملکیت وغیرہ بر موقع</th>
                            <th colspan="2">تصدیق آخیر شجرہ نسب</th>
                            <th colspan="2">تصدیق ملکیت و قبضہ کاشت وغیرہ</th>
                            <th rowspan="2">تبصرہ</th>
                        </tr>
                        <tr>
                            <th>ضلع نام</th>
                            <th>تحصیل نام</th>
                            <th>موضع نام</th>
                            <th>پٹوار نام</th>
                            <th>اہلکار نام</th>
                            <th>از تاریخ</th>
                            <th>تا تاریخ</th>
                            <th>تصدیق ملکیت/پیمود شدہ نمبرات خسرہ</th>
                            <th>تعداد برامدہ بدرات</th>
                            <th>تصدیق ملکیت و قبضہ کاشت نمبرات خسرہ</th>
                            <th>تعداد برامدہ بدرات</th>
                            <th>تعداد گھری</th>
                            <th>تعداد برامدہ بدرات</th>
                            <th>مقابلہ کھتونی ہمراہ کاپی چومنڈہ</th>
                            <th>تعداد برامدہ بدرات</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($records as $index => $rec)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $rec->districtNameUrdu }}</td>
                            <td>{{ $rec->tehsilNameUrdu }}</td>
                            <td>{{ $rec->mozaNameUrdu }}</td>
                            <td>{{ $rec->patwari_nam }}</td>
                            <td>{{ $rec->ahalkar_nam }}</td>
                            <td >{{ $from_date ? date('d-m-Y', strtotime($from_date)) : '' }}</td>
                            <td >{{ $to_date ? date('d-m-Y', strtotime($to_date)) : '' }}</td>
                            <td class="{{ $rec->tasdeeq_milkiat_pemuda_khasra > 0 ? 'value-cell' : '' }}">{{ $rec->tasdeeq_milkiat_pemuda_khasra == 0 ? '-' : $rec->tasdeeq_milkiat_pemuda_khasra }}</td>
                            <td class="{{ $rec->tasdeeq_milkiat_pemuda_khasra_badrat > 0 ? 'value-cell' : '' }}">{{ $rec->tasdeeq_milkiat_pemuda_khasra_badrat == 0 ? '-' : $rec->tasdeeq_milkiat_pemuda_khasra_badrat }}</td>
                            <td class="{{ $rec->tasdeeq_milkiat_qabza_kasht_khasra > 0 ? 'value-cell' : '' }}">{{ $rec->tasdeeq_milkiat_qabza_kasht_khasra == 0 ? '-' : $rec->tasdeeq_milkiat_qabza_kasht_khasra }}</td>
                            <td class="{{ $rec->tasdeeq_milkiat_qabza_kasht_badrat > 0 ? 'value-cell' : '' }}">{{ $rec->tasdeeq_milkiat_qabza_kasht_badrat == 0 ? '-' : $rec->tasdeeq_milkiat_qabza_kasht_badrat }}</td>
                            <td class="{{ $rec->tasdeeq_shajra_nasab_guri > 0 ? 'value-cell' : '' }}">{{ $rec->tasdeeq_shajra_nasab_guri == 0 ? '-' : $rec->tasdeeq_shajra_nasab_guri }}</td>
                            <td class="{{ $rec->tasdeeq_shajra_nasab_badrat > 0 ? 'value-cell' : '' }}">{{ $rec->tasdeeq_shajra_nasab_badrat == 0 ? '-' : $rec->tasdeeq_shajra_nasab_badrat }}</td>
                            <td class="{{ $rec->muqabala_khatoni_chomanda > 0 ? 'value-cell' : '' }}">{{ $rec->muqabala_khatoni_chomanda == 0 ? '-' : $rec->muqabala_khatoni_chomanda }}</td>
                            <td class="{{ $rec->muqabala_khatoni_chomanda_badrat > 0 ? 'value-cell' : '' }}">{{ $rec->muqabala_khatoni_chomanda_badrat == 0 ? '-' : $rec->muqabala_khatoni_chomanda_badrat }}</td>
                            <td>{{ $rec->tabsara }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- تکمیلی عمل رپورٹ section with table -->
    <div class="row">
        <div class="col-md-12">
            <div class="dashboard-header">
            <h3>تکمیلی عمل خلاصہ ({{ $from_date ? date('d-m-Y', strtotime($from_date)) : '' }} تا {{ $to_date ? date('d-m-Y', strtotime($to_date)) : '' }})</h3>
            </div>
            <div class="report-container">
                <table id="completionProcessTable">
                    <thead>
                        <tr>
                            <th>نمبر شمار</th>
                            <th>نام ضلع</th>
                            <th>نام تحصیل</th>
                            <th>نام موضع</th>
                            <th>نام اہلکار</th>
                            <th>میزان کھاتہ دار/کھتونی</th>
                            <th>پختہ کھتونی درانڈکس خسرہ</th>
                            <th>درستی بدرات</th>
                            <th>تحریر نقل شجرہ نسب</th>
                            <th>تحریر شجرہ نسب مالکان قبضہ</th>
                            <th>پختہ کھاتاجات</th>
                            <th>خام کھاتہ جات در شجرہ نسب</th>
                            <th>تحریر مشترکہ کھاتہ</th>
                            <th>پختہ نمبرواں در کھتونی</th>
                            <th>خام نمبرواں در کھتونی</th>
                            <th>تصدیق آخیر</th>
                            <th>متفرق کام</th>
                            <th>از تاریخ</th>
                            <th>تا تاریخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($completion_process as $index => $cp)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $cp->districtNameUrdu }}</td>
                            <td>{{ $cp->tehsilNameUrdu }}</td>
                            <td>{{ $cp->mozaNameUrdu }}</td>
                            <td>{{ $cp->employee_name }} @if(!empty($cp->employee_type_title))<small>({{ $cp->employee_type_title }})</small>@endif</td>
                            <td class="{{ $cp->mizan_khata_dar_khatoni > 0 ? 'value-cell' : '' }}">{{ $cp->mizan_khata_dar_khatoni == 0 ? '-' : $cp->mizan_khata_dar_khatoni }}</td>
                            <td class="{{ $cp->pukhta_khatoni_drandkas_khasra > 0 ? 'value-cell' : '' }}">{{ $cp->pukhta_khatoni_drandkas_khasra == 0 ? '-' : $cp->pukhta_khatoni_drandkas_khasra }}</td>
                            <td class="{{ $cp->durusti_badrat > 0 ? 'value-cell' : '' }}">{{ $cp->durusti_badrat == 0 ? '-' : $cp->durusti_badrat }}</td>
                            <td class="{{ $cp->tehreer_naqal_shajra_nasab > 0 ? 'value-cell' : '' }}">{{ $cp->tehreer_naqal_shajra_nasab == 0 ? '-' : $cp->tehreer_naqal_shajra_nasab }}</td>
                            <td class="{{ $cp->tehreer_shajra_nasab_malkan_qabza > 0 ? 'value-cell' : '' }}">{{ $cp->tehreer_shajra_nasab_malkan_qabza == 0 ? '-' : $cp->tehreer_shajra_nasab_malkan_qabza }}</td>
                            <td class="{{ $cp->pukhta_khatajat > 0 ? 'value-cell' : '' }}">{{ $cp->pukhta_khatajat == 0 ? '-' : $cp->pukhta_khatajat }}</td>
                            <td class="{{ $cp->kham_khatajat_dar_shajra_nasab > 0 ? 'value-cell' : '' }}">{{ $cp->kham_khatajat_dar_shajra_nasab == 0 ? '-' : $cp->kham_khatajat_dar_shajra_nasab }}</td>
                            <td class="{{ $cp->tehreer_mushtarka_khata > 0 ? 'value-cell' : '' }}">{{ $cp->tehreer_mushtarka_khata == 0 ? '-' : $cp->tehreer_mushtarka_khata }}</td>
                            <td class="{{ $cp->pukhta_numberwan_dar_khatoni > 0 ? 'value-cell' : '' }}">{{ $cp->pukhta_numberwan_dar_khatoni == 0 ? '-' : $cp->pukhta_numberwan_dar_khatoni }}</td>
                            <td class="{{ $cp->kham_numberwan_dar_khatoni > 0 ? 'value-cell' : '' }}">{{ $cp->kham_numberwan_dar_khatoni == 0 ? '-' : $cp->kham_numberwan_dar_khatoni }}</td>
                            <td class="{{ $cp->tasdeeq_akhir > 0 ? 'value-cell' : '' }}">{{ $cp->tasdeeq_akhir == 0 ? '-' : $cp->tasdeeq_akhir }}</td>
                            <td class="{{ $cp->mutafarriq_kaam > 0 ? 'value-cell' : '' }}">{{ $cp->mutafarriq_kaam == 0 ? '-' : $cp->mutafarriq_kaam }}</td>
                            <td>{{ $from_date ? date('d-m-Y', strtotime($from_date)) : '' }}</td>
                            <td>{{ $to_date ? date('d-m-Y', strtotime($to_date)) : '' }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
   

</div>
@endsection
