@extends('layouts.app')

@section('title', 'تکمیلی عمل')

@section('content')
<div class="container" dir="rtl">
    <style>
        thead th {
            border:1px solid #ddd8d8 !important;
        }
        .value-cell {
            background-color: #d4edda !important;
        }
    </style>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="{{ route('completion_process.create') }}" class="btn btn-success">
            <i class="fa fa-plus"></i> نیا اندراج
        </a>
        <center><h3 class="mb-0">تکمیلی عمل کی فہرست</h3></center>
    </div>

    <div class="table-responsive">
        <table class="table table-striped table-hover table-bordered text-center">
            <thead class="thead-dark">
                <tr>
                    <th>نمبر شمار</th>
                    <th>نام ضلع</th>
                    <th>نام تحصیل</th>
                    <th>نام موضع</th>
                    <th>نام اہلکار</th>
            <th>اہلکار کی قسم</th>
                    <th>میزان کھاتہ دار/کھتونی</th>
                    <th>پختہ کھتونی درانڈکس خسرہ</th>
                    <th>درستی بدرات</th>
                    <th>تحریر نقل شجرہ نسب</th>
                    <th>تحریر شجرہ نسب مالکان قبضہ</th>
                    <th>پختہ کھاتاجات</th>
                    <th>خام کھاتہ جات در شجرہ نسب</th>
                    <th>تحریر مشترکہ کھاتہ</th>
                    <th>پختہ نمبرواں در کھتونی</th>
                    <th>خام نمبرواں در کھتونی</th>
                    <th>تصدیق آخیر</th>
                    <th>متفرق کام</th>
                    <th>تاریخ</th>
                    <th class="no-print">عمل</th>
                </tr>
            </thead>
            <tbody>
                @foreach($completion_process as $cp)
                <tr>
                    <td>{{ ($completion_process->currentPage() - 1) * $completion_process->perPage() + $loop->iteration }}</td>
                    <td>{{ $cp->districtNameUrdu }}</td>
                    <td>{{ $cp->tehsilNameUrdu }}</td>
                    <td>{{ $cp->mozaNameUrdu }}</td>
                    <td>{{ $cp->employee_name }}</td>
                    <td>{{ $cp->employee_type_title }}</td>
                    <td class="{{ $cp->mizan_khata_dar_khatoni > 0 ? 'value-cell' : '' }}">{{ $cp->mizan_khata_dar_khatoni == 0 ? '-' : $cp->mizan_khata_dar_khatoni }}</td>
                    <td class="{{ $cp->pukhta_khatoni_drandkas_khasra > 0 ? 'value-cell' : '' }}">{{ $cp->pukhta_khatoni_drandkas_khasra == 0 ? '-' : $cp->pukhta_khatoni_drandkas_khasra }}</td>
                    <td class="{{ $cp->durusti_badrat > 0 ? 'value-cell' : '' }}">{{ $cp->durusti_badrat == 0 ? '-' : $cp->durusti_badrat }}</td>
                    <td class="{{ $cp->tehreer_naqal_shajra_nasab > 0 ? 'value-cell' : '' }}">{{ $cp->tehreer_naqal_shajra_nasab == 0 ? '-' : $cp->tehreer_naqal_shajra_nasab }}</td>
                    <td class="{{ $cp->tehreer_shajra_nasab_malkan_qabza > 0 ? 'value-cell' : '' }}">{{ $cp->tehreer_shajra_nasab_malkan_qabza == 0 ? '-' : $cp->tehreer_shajra_nasab_malkan_qabza }}</td>
                    <td class="{{ $cp->pukhta_khatajat > 0 ? 'value-cell' : '' }}">{{ $cp->pukhta_khatajat == 0 ? '-' : $cp->pukhta_khatajat }}</td>
                    <td class="{{ $cp->kham_khatajat_dar_shajra_nasab > 0 ? 'value-cell' : '' }}">{{ $cp->kham_khatajat_dar_shajra_nasab == 0 ? '-' : $cp->kham_khatajat_dar_shajra_nasab }}</td>
                    <td class="{{ $cp->tehreer_mushtarka_khata > 0 ? 'value-cell' : '' }}">{{ $cp->tehreer_mushtarka_khata == 0 ? '-' : $cp->tehreer_mushtarka_khata }}</td>
                    <td class="{{ $cp->pukhta_numberwan_dar_khatoni > 0 ? 'value-cell' : '' }}">{{ $cp->pukhta_numberwan_dar_khatoni == 0 ? '-' : $cp->pukhta_numberwan_dar_khatoni }}</td>
                    <td class="{{ $cp->kham_numberwan_dar_khatoni > 0 ? 'value-cell' : '' }}">{{ $cp->kham_numberwan_dar_khatoni == 0 ? '-' : $cp->kham_numberwan_dar_khatoni }}</td>
                    <td class="{{ $cp->tasdeeq_akhir > 0 ? 'value-cell' : '' }}">{{ $cp->tasdeeq_akhir == 0 ? '-' : $cp->tasdeeq_akhir }}</td>
                    <td class="{{ $cp->mutafarriq_kaam > 0 ? 'value-cell' : '' }}">{{ $cp->mutafarriq_kaam == 0 ? '-' : $cp->mutafarriq_kaam }}</td>
                    <td >{{ $cp->tareekh ? date('d-m-Y', strtotime($cp->tareekh)) : '' }}</td>
                    <td>
                        <a href="{{ route('completion_process.edit', $cp->id) }}" class="btn btn-sm btn-warning">
                            <i class="fa fa-edit"></i> ترمیم
                        </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <div class="d-flex justify-content-center">
            {{ $completion_process->links() }}
        </div>
    </div>
</div>
@endsection
