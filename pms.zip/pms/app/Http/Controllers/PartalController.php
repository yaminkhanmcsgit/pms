<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PartalController extends Controller
{
    protected $table = 'partal';

    // List all records with pagination
    public function index()
    {
        $records = DB::table($this->table)
            ->leftJoin('employees as emp_ahalkar', 'partal.ahalkar_nam', '=', 'emp_ahalkar.nam')
            ->leftJoin('employee_type as et_ahalkar', 'emp_ahalkar.ahalkar_type', '=', 'et_ahalkar.ahalkar_type_id')
            ->leftJoin('employees as emp_patwari', 'partal.patwari_nam', '=', 'emp_patwari.nam')
            ->leftJoin('employee_type as et_patwari', 'emp_patwari.ahalkar_type', '=', 'et_patwari.ahalkar_type_id')
            ->leftJoin('districts', 'partal.zila_nam', '=', 'districts.districtId')
            ->leftJoin('tehsils', 'partal.tehsil_nam', '=', 'tehsils.tehsilId')
            ->leftJoin('mozas', 'partal.moza_nam', '=', 'mozas.mozaId')
            ->select(
                'partal.*',
                'et_ahalkar.ahalkar_title as ahalkar_title',
                'et_patwari.ahalkar_title as patwari_title',
                'districts.districtNameUrdu as districtNameUrdu',
                'tehsils.tehsilNameUrdu as tehsilNameUrdu',
                'mozas.mozaNameUrdu as mozaNameUrdu',
                'districts.districtId as zila_id',
                'tehsils.tehsilId as tehsil_id',
                'mozas.mozaId as moza_id'
            )
            ->orderBy('partal.id', 'desc')
            ->paginate(10);
        return view('partal.index', compact('records'));
    }

    // Show form to create a new record
    public function create()
    {
    $employees = DB::table('employees')->orderBy('nam')->get();
    return view('partal.create', compact('employees'));
    }

    // Store a new record
    public function store(Request $request)
    {
        $validated = $request->validate([
            'zila_id' => 'nullable|integer',
            'tehsil_id' => 'nullable|integer',
            'moza_id' => 'nullable|integer',
            'patwari_nam' => 'nullable|string|max:100',
            'ahalkar_nam' => 'nullable|string|max:100',
            'tareekh_partal' => 'nullable|date',
            'tasdeeq_milkiat_pemuda_khasra' => 'nullable|integer',
            'tasdeeq_milkiat_pemuda_khasra_badrat' => 'nullable|integer',
            'tasdeeq_milkiat_qabza_kasht_khasra' => 'nullable|integer',
            'tasdeeq_milkiat_qabza_kasht_badrat' => 'nullable|integer',
            'tasdeeq_shajra_nasab_guri' => 'nullable|integer',
            'tasdeeq_shajra_nasab_badrat' => 'nullable|integer',
            'muqabala_khatoni_chomanda' => 'nullable|integer',
            'muqabala_khatoni_chomanda_badrat' => 'nullable|integer',
            'tabsara' => 'nullable|string',
            'operator_id' => 'nullable|integer',
        ]);

        // Convert IDs to names
        if ($validated['zila_id']) {
            $validated['zila_nam'] = DB::table('districts')->where('districtId', $validated['zila_id'])->value('districtNameUrdu');
        }
        if ($validated['tehsil_id']) {
            $validated['tehsil_nam'] = DB::table('tehsils')->where('tehsilId', $validated['tehsil_id'])->value('tehsilNameUrdu');
        }
        if ($validated['moza_id']) {
            $validated['moza_nam'] = DB::table('mozas')->where('mozaId', $validated['moza_id'])->value('mozaNameUrdu');
        }
        unset($validated['zila_id'], $validated['tehsil_id'], $validated['moza_id']);

        DB::table($this->table)->insert($validated);

        return redirect()->route('partal.index')
                         ->with('success', 'Record added successfully.');
    }

    // Show form to edit a record
    public function edit($id)
    {
        $record = DB::table($this->table)
            ->leftJoin('districts', 'partal.zila_nam', '=', 'districts.districtId')
            ->leftJoin('tehsils', 'partal.tehsil_nam', '=', 'tehsils.tehsilId')
            ->leftJoin('mozas', 'partal.moza_nam', '=', 'mozas.mozaId')
            ->select(
                'partal.*',
                'districts.districtId as zila_id',
                'tehsils.tehsilId as tehsil_id',
                'mozas.mozaId as moza_id'
            )
            ->where('partal.id', $id)
            ->first();
        $employees = DB::table('employees')->orderBy('nam')->get();
        return view('partal.edit', compact('record', 'employees'));
    }

    // Update a record
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'zila_id' => 'nullable|integer',
            'tehsil_id' => 'nullable|integer',
            'moza_id' => 'nullable|integer',
            'patwari_nam' => 'nullable|string|max:100',
            'ahalkar_nam' => 'nullable|string|max:100',
            'tareekh_partal' => 'nullable|date',
            'tasdeeq_milkiat_pemuda_khasra' => 'nullable|integer',
            'tasdeeq_milkiat_pemuda_khasra_badrat' => 'nullable|integer',
            'tasdeeq_milkiat_qabza_kasht_khasra' => 'nullable|integer',
            'tasdeeq_milkiat_qabza_kasht_badrat' => 'nullable|integer',
            'tasdeeq_shajra_nasab_guri' => 'nullable|integer',
            'tasdeeq_shajra_nasab_badrat' => 'nullable|integer',
            'muqabala_khatoni_chomanda' => 'nullable|integer',
            'muqabala_khatoni_chomanda_badrat' => 'nullable|integer',
            'tabsara' => 'nullable|string',
            'operator_id' => 'nullable|integer',
        ]);

        // Convert IDs to names
        if ($validated['zila_id']) {
            $validated['zila_nam'] = DB::table('districts')->where('districtId', $validated['zila_id'])->value('districtNameUrdu');
        }
        if ($validated['tehsil_id']) {
            $validated['tehsil_nam'] = DB::table('tehsils')->where('tehsilId', $validated['tehsil_id'])->value('tehsilNameUrdu');
        }
        if ($validated['moza_id']) {
            $validated['moza_nam'] = DB::table('mozas')->where('mozaId', $validated['moza_id'])->value('mozaNameUrdu');
        }
        unset($validated['zila_id'], $validated['tehsil_id'], $validated['moza_id']);

        DB::table($this->table)->where('id', $id)->update($validated);

        return redirect()->route('partal.index')
                         ->with('success', 'Record updated successfully.');
    }

    // Delete a record
    public function destroy($id)
    {
        DB::table($this->table)->where('id', $id)->delete();
        return redirect()->route('partal.index')
                         ->with('success', 'Record deleted successfully.');
    }
}

