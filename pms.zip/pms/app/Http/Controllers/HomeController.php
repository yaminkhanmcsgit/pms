<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        $district = 'مالاکنڈ ڈویژن';
        $report_date = date('Y-m-d');

        // Fetch all districts and tehsils for dropdowns
        $districts = DB::table('districts')->get();
        $tehsils = DB::table('tehsils')->get();

        // Get selected filter values
        $selected_district = $request->input('district_id');
        $selected_tehsil = $request->input('tehsil_id');
        $from_date = $request->input('from_date');
        $to_date = $request->input('to_date');

        // Default to last 7 days if no dates provided
        if (!$from_date || !$to_date) {
            $to_date = date('Y-m-d');
            $from_date = date('Y-m-d', strtotime('-6 days'));
        }

        // Grouped partal records by district, tehsil, moza, employee
      $partal_query = DB::table('partal')
    ->leftJoin('districts', 'partal.zila_nam', '=', 'districts.districtId')
    ->leftJoin('tehsils', 'partal.tehsil_nam', '=', 'tehsils.tehsilId')
    ->leftJoin('mozas', 'partal.moza_nam', '=', 'mozas.mozaId')
    ->when(Schema::hasColumn('partal', 'tareekh_partal'), function($q) use ($from_date, $to_date) {
        $q->whereBetween('partal.tareekh_partal', [$from_date, $to_date]);
    })
    ->groupBy(
        'districts.districtId',
        'districts.districtNameUrdu',   // added
        'tehsils.tehsilId',
        'tehsils.tehsilNameUrdu',       // added
        'mozas.mozaId',
        'mozas.mozaNameUrdu',           // added
        'partal.patwari_nam',
        'partal.ahalkar_nam'
    )
    ->select(
        'districts.districtId',
        'tehsils.tehsilId',
        'mozas.mozaId',
        'districts.districtNameUrdu as districtNameUrdu',
        'tehsils.tehsilNameUrdu as tehsilNameUrdu',
        'mozas.mozaNameUrdu as mozaNameUrdu',
        'partal.patwari_nam',
        'partal.ahalkar_nam',
        DB::raw('SUM(COALESCE(partal.tasdeeq_milkiat_pemuda_khasra,0)) AS tasdeeq_milkiat_pemuda_khasra'),
        DB::raw('SUM(COALESCE(partal.tasdeeq_milkiat_pemuda_khasra_badrat,0)) AS tasdeeq_milkiat_pemuda_khasra_badrat'),
        DB::raw('SUM(COALESCE(partal.tasdeeq_milkiat_qabza_kasht_khasra,0)) AS tasdeeq_milkiat_qabza_kasht_khasra'),
        DB::raw('SUM(COALESCE(partal.tasdeeq_milkiat_qabza_kasht_badrat,0)) AS tasdeeq_milkiat_qabza_kasht_badrat'),
        DB::raw('SUM(COALESCE(partal.tasdeeq_shajra_nasab_guri,0)) AS tasdeeq_shajra_nasab_guri'),
        DB::raw('SUM(COALESCE(partal.tasdeeq_shajra_nasab_badrat,0)) AS tasdeeq_shajra_nasab_badrat'),
        DB::raw('SUM(COALESCE(partal.muqabala_khatoni_chomanda,0)) AS muqabala_khatoni_chomanda'),
        DB::raw('SUM(COALESCE(partal.muqabala_khatoni_chomanda_badrat,0)) AS muqabala_khatoni_chomanda_badrat'),
        DB::raw('GROUP_CONCAT(DISTINCT partal.tabsara SEPARATOR "; ") AS tabsara')
    )
    ->orderBy('districts.districtId')
    ->orderBy('tehsils.tehsilId')
    ->orderBy('mozas.mozaId')
    ->get();

        $records = $partal_query;

        // Grouped completion_process records by district, tehsil, moza, employee, type
        $cp_query = DB::table('completion_process')
            ->leftJoin('employees', 'completion_process.employee_id', '=', 'employees.id')
            ->leftJoin('employee_type', 'employees.ahalkar_type', '=', 'employee_type.ahalkar_type_id')
            ->leftJoin('districts', 'completion_process.zila_id', '=', 'districts.districtId')
            ->leftJoin('tehsils', 'completion_process.tehsil_id', '=', 'tehsils.tehsilId')
            ->leftJoin('mozas', 'completion_process.moza_id', '=', 'mozas.mozaId')
            ->leftJoin('completion_process_types', 'completion_process.completion_process_type_id', '=', 'completion_process_types.id')
            ->when($selected_district, function($q) use ($selected_district) { $q->where('completion_process.zila_id', $selected_district); })
            ->when($selected_tehsil, function($q) use ($selected_tehsil) { $q->where('completion_process.tehsil_id', $selected_tehsil); })
            ->when(Schema::hasColumn('completion_process', 'tareekh'), function($q) use ($from_date, $to_date) { $q->whereBetween('completion_process.tareekh', [$from_date, $to_date]); })
            ->groupBy(
                'completion_process.zila_id',
                'districts.districtNameUrdu',
                'completion_process.tehsil_id',
                'tehsils.tehsilNameUrdu',
                'completion_process.moza_id',
                'mozas.mozaNameUrdu',
                'completion_process.employee_id',
                'employees.nam',
                'employee_type.ahalkar_title',
                'completion_process.completion_process_type_id',
                'completion_process_types.title_ur'
            )
            ->select(
                'completion_process.zila_id', 'districts.districtNameUrdu as districtNameUrdu',
                'completion_process.tehsil_id', 'tehsils.tehsilNameUrdu as tehsilNameUrdu',
                'completion_process.moza_id', 'mozas.mozaNameUrdu as mozaNameUrdu',
                'completion_process.employee_id', 'employees.nam as employee_name',
                'employee_type.ahalkar_title as employee_type_title',
                'completion_process.completion_process_type_id', 'completion_process_types.title_ur as completion_process_type_title',
                DB::raw("SUM(CASE WHEN completion_process.completion_process_type_id = 1 AND COALESCE(TRIM(completion_process.type_value), '') <> '' AND completion_process.type_value REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' THEN CAST(completion_process.type_value AS UNSIGNED) ELSE 0 END) AS mizan_khata_dar_khatoni"),
                DB::raw("SUM(CASE WHEN completion_process.completion_process_type_id = 2 AND COALESCE(TRIM(completion_process.type_value), '') <> '' AND completion_process.type_value REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' THEN CAST(completion_process.type_value AS UNSIGNED) ELSE 0 END) AS pukhta_khatoni_drandkas_khasra"),
                DB::raw("SUM(CASE WHEN completion_process.completion_process_type_id = 3 AND COALESCE(TRIM(completion_process.type_value), '') <> '' AND completion_process.type_value REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' THEN CAST(completion_process.type_value AS UNSIGNED) ELSE 0 END) AS durusti_badrat"),
                DB::raw("SUM(CASE WHEN completion_process.completion_process_type_id = 4 AND COALESCE(TRIM(completion_process.type_value), '') <> '' AND completion_process.type_value REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' THEN CAST(completion_process.type_value AS UNSIGNED) ELSE 0 END) AS tehreer_naqal_shajra_nasab"),
                DB::raw("SUM(CASE WHEN completion_process.completion_process_type_id = 5 AND COALESCE(TRIM(completion_process.type_value), '') <> '' AND completion_process.type_value REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' THEN CAST(completion_process.type_value AS UNSIGNED) ELSE 0 END) AS tehreer_shajra_nasab_malkan_qabza"),
                DB::raw("SUM(CASE WHEN completion_process.completion_process_type_id = 6 AND COALESCE(TRIM(completion_process.type_value), '') <> '' AND completion_process.type_value REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' THEN CAST(completion_process.type_value AS UNSIGNED) ELSE 0 END) AS pukhta_khatajat"),
                DB::raw("SUM(CASE WHEN completion_process.completion_process_type_id = 7 AND COALESCE(TRIM(completion_process.type_value), '') <> '' AND completion_process.type_value REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' THEN CAST(completion_process.type_value AS UNSIGNED) ELSE 0 END) AS kham_khatajat_dar_shajra_nasab"),
                DB::raw("SUM(CASE WHEN completion_process.completion_process_type_id = 8 AND COALESCE(TRIM(completion_process.type_value), '') <> '' AND completion_process.type_value REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' THEN CAST(completion_process.type_value AS UNSIGNED) ELSE 0 END) AS tehreer_mushtarka_khata"),
                DB::raw("SUM(CASE WHEN completion_process.completion_process_type_id = 9 AND COALESCE(TRIM(completion_process.type_value), '') <> '' AND completion_process.type_value REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' THEN CAST(completion_process.type_value AS UNSIGNED) ELSE 0 END) AS pukhta_numberwan_dar_khatoni"),
                DB::raw("SUM(CASE WHEN completion_process.completion_process_type_id = 10 AND COALESCE(TRIM(completion_process.type_value), '') <> '' AND completion_process.type_value REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' THEN CAST(completion_process.type_value AS UNSIGNED) ELSE 0 END) AS kham_numberwan_dar_khatoni"),
                DB::raw("SUM(CASE WHEN completion_process.completion_process_type_id = 11 AND COALESCE(TRIM(completion_process.type_value), '') <> '' AND completion_process.type_value REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' THEN CAST(completion_process.type_value AS UNSIGNED) ELSE 0 END) AS tasdeeq_akhir"),
                DB::raw("SUM(CASE WHEN completion_process.completion_process_type_id = 12 AND COALESCE(TRIM(completion_process.type_value), '') <> '' AND completion_process.type_value REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' THEN CAST(completion_process.type_value AS UNSIGNED) ELSE 0 END) AS mutafarriq_kaam")
            )
            ->orderBy('completion_process.zila_id')
            ->orderBy('completion_process.tehsil_id')
            ->orderBy('completion_process.moza_id')
            ->orderBy('completion_process.employee_id')
            ->orderBy('completion_process.completion_process_type_id')
            ->get();
        $completion_process = $cp_query;

       

        return view('dashboard', compact('district', 'report_date', 'records', 'completion_process', 'districts', 'tehsils', 'selected_district', 'selected_tehsil', 'from_date', 'to_date'));
    }
}
