<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CompletionProcessController extends Controller
{ 
    protected $table = 'completion_process';

    // List all records with pagination
    public function index()
    {
        $completion_process = DB::table($this->table)
            ->leftJoin('employees', $this->table.'.employee_id', '=', 'employees.id')
            ->leftJoin('employee_type', 'employees.ahalkar_type', '=', 'employee_type.ahalkar_type_id')
            ->leftJoin('districts', $this->table.'.zila_id', '=', 'districts.districtId')
            ->leftJoin('tehsils', $this->table.'.tehsil_id', '=', 'tehsils.tehsilId')
            ->leftJoin('mozas', $this->table.'.moza_id', '=', 'mozas.mozaId')
            ->leftJoin('completion_process_types', $this->table.'.completion_process_type_id', '=', 'completion_process_types.id')
            ->select(
                $this->table.'.*',
                'employees.nam as employee_name',
                'employee_type.ahalkar_title as employee_type_title',
                'districts.districtNameUrdu as districtNameUrdu',
                'tehsils.tehsilNameUrdu as tehsilNameUrdu',
                'mozas.mozaNameUrdu as mozaNameUrdu',
                'completion_process_types.title_ur as completion_process_type_title',
                DB::raw("IF(\n                    ".$this->table.".completion_process_type_id = 1 AND COALESCE(TRIM(".$this->table.".type_value), '') <> '', ".$this->table.".type_value, '-'\n                ) AS mizan_khata_dar_khatoni"),
                DB::raw("IF(\n                    ".$this->table.".completion_process_type_id = 2 AND COALESCE(TRIM(".$this->table.".type_value), '') <> '', ".$this->table.".type_value, '-'\n                ) AS pukhta_khatoni_drandkas_khasra"),
                DB::raw("IF(\n                    ".$this->table.".completion_process_type_id = 3 AND COALESCE(TRIM(".$this->table.".type_value), '') <> '', ".$this->table.".type_value, '-'\n                ) AS durusti_badrat"),
                DB::raw("IF(\n                    ".$this->table.".completion_process_type_id = 4 AND COALESCE(TRIM(".$this->table.".type_value), '') <> '', ".$this->table.".type_value, '-'\n                ) AS tehreer_naqal_shajra_nasab"),
                DB::raw("IF(\n                    ".$this->table.".completion_process_type_id = 5 AND COALESCE(TRIM(".$this->table.".type_value), '') <> '', ".$this->table.".type_value, '-'\n                ) AS tehreer_shajra_nasab_malkan_qabza"),
                DB::raw("IF(\n                    ".$this->table.".completion_process_type_id = 6 AND COALESCE(TRIM(".$this->table.".type_value), '') <> '', ".$this->table.".type_value, '-'\n                ) AS pukhta_khatajat"),
                DB::raw("IF(\n                    ".$this->table.".completion_process_type_id = 7 AND COALESCE(TRIM(".$this->table.".type_value), '') <> '', ".$this->table.".type_value, '-'\n                ) AS kham_khatajat_dar_shajra_nasab"),
                DB::raw("IF(\n                    ".$this->table.".completion_process_type_id = 8 AND COALESCE(TRIM(".$this->table.".type_value), '') <> '', ".$this->table.".type_value, '-'\n                ) AS tehreer_mushtarka_khata"),
                DB::raw("IF(\n                    ".$this->table.".completion_process_type_id = 9 AND COALESCE(TRIM(".$this->table.".type_value), '') <> '', ".$this->table.".type_value, '-'\n                ) AS pukhta_numberwan_dar_khatoni"),
                DB::raw("IF(\n                    ".$this->table.".completion_process_type_id = 10 AND COALESCE(TRIM(".$this->table.".type_value), '') <> '', ".$this->table.".type_value, '-'\n                ) AS kham_numberwan_dar_khatoni"),
                DB::raw("IF(\n                    ".$this->table.".completion_process_type_id = 11 AND COALESCE(TRIM(".$this->table.".type_value), '') <> '', ".$this->table.".type_value, '-'\n                ) AS tasdeeq_akhir"),
                DB::raw("IF(\n                    ".$this->table.".completion_process_type_id = 12 AND COALESCE(TRIM(".$this->table.".type_value), '') <> '', ".$this->table.".type_value, '-'\n                ) AS mutafarriq_kaam")
            )
            ->orderBy($this->table.'.id', 'desc')
            ->paginate(10);
        return view('completion_process.index', compact('completion_process'));
    }

    // Show form to create a new record
    public function create()
    {
    $districts = DB::table('districts')->orderBy('districtId')->get();
    $tehsils   = DB::table('tehsils')->orderBy('tehsilId')->get();
    $mozas     = DB::table('mozas')->orderBy('mozaId')->get();
    $employees = DB::table('employees')->orderBy('nam')->get();
    $completion_process_types = DB::table('completion_process_types')->orderBy('id')->get();
    return view('completion_process.create', compact('districts', 'tehsils', 'mozas', 'employees', 'completion_process_types'));
    }

    // Store a new record
    public function store(Request $request)
    {
        $validated = $request->validate([
            'completion_process_type_id' => 'required|integer',
            'type_value' => 'nullable|string',
            'zila_id' => 'nullable|integer',
            'tehsil_id' => 'nullable|integer',
            'moza_id' => 'nullable|integer',
            'employee_id' => 'nullable|integer',
            'tareekh' => 'nullable|date',
            'tabsara' => 'nullable|string',
            'operator_id' => 'nullable|integer',
        ]);

        DB::table($this->table)->insert($validated);

        return redirect()->route('completion_process.index')->with('success', 'Record added successfully.');
    }

    // Show form to edit a record
    public function edit($id)
    {
    $completion_process = DB::table($this->table)->where('id', $id)->first();
    $districts = DB::table('districts')->orderBy('districtId')->get();
    $tehsils   = DB::table('tehsils')->orderBy('tehsilId')->get();
    $mozas     = DB::table('mozas')->orderBy('mozaId')->get();
    $employees = DB::table('employees')->orderBy('nam')->get();
    $completion_process_types = DB::table('completion_process_types')->orderBy('id')->get();
    return view('completion_process.edit', compact('completion_process', 'districts', 'tehsils', 'mozas', 'employees', 'completion_process_types'));
    }

    // Update a record
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'completion_process_type_id' => 'required|integer',
            'type_value' => 'nullable|string',
            'zila_id' => 'nullable|integer',
            'tehsil_id' => 'nullable|integer',
            'moza_id' => 'nullable|integer',
            'employee_id' => 'nullable|integer',
            'tareekh' => 'nullable|date',
            'tabsara' => 'nullable|string',
            'operator_id' => 'nullable|integer',
        ]);

        DB::table($this->table)->where('id', $id)->update($validated);

        return redirect()->route('completion_process.index')
                         ->with('success', 'Record updated successfully.');
    }

    // Delete a record
    public function destroy($id)
    {
        DB::table($this->table)->where('id', $id)->delete();
        return redirect()->route('completion_process.index')
                         ->with('success', 'Record deleted successfully.');
    }
}
