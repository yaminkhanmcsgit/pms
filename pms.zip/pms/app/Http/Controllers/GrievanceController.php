<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GrievanceController extends Controller
{
    public function index()
    {
        $grievances = DB::table('grievances')
            ->leftJoin('grievance_types', 'grievances.grievance_type_id', '=', 'grievance_types.id')
            ->leftJoin('grievance_statuses', 'grievances.status_id', '=', 'grievance_statuses.id')
            ->leftJoin('districts', 'grievances.district', '=', 'districts.districtId')
            ->leftJoin('tehsils', 'grievances.tehsil', '=', 'tehsils.tehsilId')
            ->leftJoin('mozas', 'grievances.village_name', '=', 'mozas.mozaId')
            ->select(
                'grievances.*',
                'grievance_types.name as grievance_type_name',
                'grievance_statuses.name as status_name',
                'grievance_statuses.color_class as status_color',
                'districts.districtNameUrdu as district_name',
                'tehsils.tehsilNameUrdu as tehsil_name',
                'mozas.mozaNameUrdu as moza_name'
            )
            ->latest()
            ->paginate(10);

        return view('grievances.index', compact('grievances'));
    }

    public function create()
    {
        $types = DB::table('grievance_types')->get();
        $statuses = DB::table('grievance_statuses')->get();

        return view('grievances.create', compact('types', 'statuses'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'district_id' => 'required|integer',
            'tehsil_id' => 'required|integer',
            'moza_id' => 'required|integer',
            'applicant_name' => 'required|string|max:255',
            'father_name' => 'required|string|max:255',
            'cnic' => 'required|string|max:20',
            'application_date' => 'required|date',
            'grievance_type_id' => 'required|integer',
            'status_id' => 'required|integer',
        ]);

        DB::table('grievances')->insert([
            'district' => $request->district_id,
            'tehsil' => $request->tehsil_id,
            'village_name' => $request->moza_id,
            'applicant_name' => $request->applicant_name,
            'father_name' => $request->father_name,
            'cnic' => $request->cnic,
            'address' => $request->address,
            'nature_of_grievance' => $request->nature_of_grievance,
            'grievance_type_id' => $request->grievance_type_id,
            'grievance_description' => $request->grievance_description,
            'status_id' => $request->status_id,
            'application_date' => $request->application_date,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return redirect()->route('grievances.index')->with('success', 'Grievance submitted successfully.');
    }

    public function show($id)
    {
        $grievance = DB::table('grievances')
            ->leftJoin('grievance_types', 'grievances.grievance_type_id', '=', 'grievance_types.id')
            ->leftJoin('grievance_statuses', 'grievances.status_id', '=', 'grievance_statuses.id')
            ->leftJoin('districts', 'grievances.district', '=', 'districts.districtId')
            ->leftJoin('tehsils', 'grievances.tehsil', '=', 'tehsils.tehsilId')
            ->leftJoin('mozas', 'grievances.village_name', '=', 'mozas.mozaId')
            ->select(
                'grievances.*',
                'grievance_types.name as grievance_type_name',
                'grievance_statuses.name as status_name',
                'grievance_statuses.color_class as status_color',
                'districts.districtNameUrdu as district_name',
                'tehsils.tehsilNameUrdu as tehsil_name',
                'mozas.mozaNameUrdu as moza_name'
            )
            ->where('grievances.id', $id)
            ->first();

        if (!$grievance) {
            return response()->json(['success' => false, 'message' => 'Grievance not found.']);
        }

        return response()->json(['success' => true, 'grievance' => $grievance]);
    }

    public function edit($id)
    {
        $grievance = DB::table('grievances')
            ->leftJoin('districts', 'grievances.district', '=', 'districts.districtId')
            ->leftJoin('tehsils', 'grievances.tehsil', '=', 'tehsils.tehsilId')
            ->leftJoin('mozas', 'grievances.village_name', '=', 'mozas.mozaId')
            ->select(
                'grievances.*',
                'districts.districtNameUrdu as district_name',
                'tehsils.tehsilNameUrdu as tehsil_name',
                'mozas.mozaNameUrdu as moza_name'
            )
            ->where('grievances.id', $id)
            ->first();

        if (!$grievance) {
            return redirect()->route('grievances.index')->with('error', 'Grievance not found.');
        }

        $types = DB::table('grievance_types')->get();
        $statuses = DB::table('grievance_statuses')->get();

        return view('grievances.edit', compact('grievance', 'types', 'statuses'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'district_id' => 'required|integer',
            'tehsil_id' => 'required|integer',
            'moza_id' => 'required|integer',
            'applicant_name' => 'required|string|max:255',
            'father_name' => 'required|string|max:255',
            'cnic' => 'required|string|max:20',
            'application_date' => 'required|date',
            'grievance_type_id' => 'required|integer',
            'status_id' => 'required|integer',
        ]);

        DB::table('grievances')->where('id', $id)->update([
            'district' => $request->district_id,
            'tehsil' => $request->tehsil_id,
            'village_name' => $request->moza_id,
            'applicant_name' => $request->applicant_name,
            'father_name' => $request->father_name,
            'cnic' => $request->cnic,
            'address' => $request->address,
            'nature_of_grievance' => $request->nature_of_grievance,
            'grievance_type_id' => $request->grievance_type_id,
            'grievance_description' => $request->grievance_description,
            'status_id' => $request->status_id,
            'application_date' => $request->application_date,
            'updated_at' => now(),
        ]);

        return redirect()->route('grievances.index')->with('success', 'Grievance updated successfully.');
    }

    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'status_id' => 'nullable|integer',
            'district_id' => 'nullable|integer',
            'tehsil_id' => 'nullable|integer',
            'moza_id' => 'nullable|integer',
            'applicant_name' => 'nullable|string|max:255',
            'father_name' => 'nullable|string|max:255',
            'cnic' => 'nullable|string|max:20',
            'address' => 'nullable|string',
            'moza_name' => 'nullable|string',
            'nature_of_grievance' => 'nullable|string',
            'grievance_type' => 'nullable|string',
            'grievance_description' => 'nullable|string',
            'application_date' => 'nullable|date',
            'forwarded_by' => 'nullable|string|max:100',
            'received_by_tehsildar_date' => 'nullable|date',
            'preliminary_remarks' => 'nullable|string',
            'action_proposed' => 'nullable|string',
            'field_verification_date' => 'nullable|date',
            'decision' => 'nullable|string',
            'disposal_date' => 'nullable|date',
            'tehsildar_signature' => 'nullable|string|max:100',
            'assistant_remarks' => 'nullable|string'
        ]);

        DB::table('grievances')->where('id', $id)->update([
            'district' => $request->district_id ?: $request->district,
            'tehsil' => $request->tehsil_id ?: $request->tehsil,
            'village_name' => $request->moza_id ?: $request->village_name,
            'applicant_name' => $request->applicant_name,
            'father_name' => $request->father_name,
            'cnic' => $request->cnic,
            'address' => $request->address,
            'nature_of_grievance' => $request->nature_of_grievance,
            'grievance_type_id' => $request->grievance_type ? DB::table('grievance_types')->where('name', 'like', '%' . explode(', ', $request->grievance_type)[0] . '%')->value('id') : null,
            'grievance_description' => $request->grievance_description,
            'status_id' => $request->status_id,
            'application_date' => $request->application_date,
            'forwarded_by' => $request->forwarded_by,
            'received_by_tehsildar_date' => $request->received_by_tehsildar_date,
            'preliminary_remarks' => $request->preliminary_remarks,
            'action_proposed' => $request->action_proposed,
            'field_verification_date' => $request->field_verification_date,
            'decision' => $request->decision,
            'disposal_date' => $request->disposal_date,
            'tehsildar_signature' => $request->tehsildar_signature,
            'assistant_remarks' => $request->assistant_remarks,
            'updated_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Status updated successfully.']);
    }

    public function destroy($id)
    {
        DB::table('grievances')->where('id', $id)->delete();
        return redirect()->route('grievances.index')->with('success', 'Grievance deleted successfully.');
    }

    public function getTypes()
    {
        $types = DB::table('grievance_types')->get();
        return response()->json(['types' => $types]);
    }

    public function getStatuses()
    {
        $statuses = DB::table('grievance_statuses')->get();
        return response()->json(['statuses' => $statuses]);
    }
}