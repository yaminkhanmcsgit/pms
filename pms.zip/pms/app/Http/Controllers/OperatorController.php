<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class OperatorController extends Controller
{
    public function index() {
        $operators = DB::table('operators')
            ->leftJoin('roles', 'operators.role_id', '=', 'roles.role_id')
            ->leftJoin('districts', 'operators.zila_id', '=', 'districts.districtId')
            ->leftJoin('tehsils', 'operators.tehsil_id', '=', 'tehsils.tehsilId')
            ->select(
                'operators.*',
                'roles.title as role_title',
                'districts.districtNameUrdu as district_name',
                'tehsils.tehsilNameUrdu as tehsil_name'
            )
            ->get();
        return view('operators.index', compact('operators'));
    }

    public function create() {
    $districts = DB::table('districts')->orderBy('districtId')->get();
    $tehsils   = DB::table('tehsils')->orderBy('tehsilId')->get();
    $roles     = DB::table('roles')->orderBy('role_id')->get();
    return view('operators.create', compact('districts', 'tehsils', 'roles'));
    }

    public function store(Request $request) {
        $request->validate([
            'zila_id' => 'required|integer',
            'tehsil_id' => 'required|integer',
            'username' => 'required|string|max:100|unique:operators',
            'password' => 'required|string|min:6',
            'full_name' => 'nullable|string|max:150',
            'role_id' => 'nullable|integer',
        ]);

        DB::table('operators')->insert([
            'zila_id' => $request->zila_id,
            'tehsil_id' => $request->tehsil_id,
            'username' => $request->username,
            'password' => $request->password, // WARNING: Plain text, not secure
            'full_name' => $request->full_name,
            'role_id' => $request->role_id,
            'created_at' => now(),
        ]);

        return redirect()->route('operators.index')->with('success', 'Operator created successfully.');
    }

    public function edit($id) {
    $operator = DB::table('operators')->where('id', $id)->first();
    $roles    = DB::table('roles')->orderBy('role_id')->get();
    return view('operators.edit', compact('operator', 'roles'));
    }

    public function update(Request $request, $id) {
        $request->validate([
            'zila_id' => 'required|integer',
            'tehsil_id' => 'required|integer',
            'username' => 'required|string|max:100|unique:operators,username,'.$id,
            'password' => 'nullable|string|min:6',
            'full_name' => 'nullable|string|max:150',
            'role_id' => 'nullable|integer',
        ]);

        $data = [
            'zila_id' => $request->zila_id,
            'tehsil_id' => $request->tehsil_id,
            'username' => $request->username,
            'full_name' => $request->full_name,
            'role_id' => $request->role_id,
        ];

        if(!empty($request->password)) {
            $data['password'] = $request->password; // WARNING: Plain text, not secure
        }

        DB::table('operators')->where('id', $id)->update($data);

        return redirect()->route('operators.index')->with('success', 'Operator updated successfully.');
    }
}
