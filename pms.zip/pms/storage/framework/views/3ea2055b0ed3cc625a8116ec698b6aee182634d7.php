

<?php $__env->startSection('title', 'رپورٹس'); ?>

<?php $__env->startPush('styles'); ?>
<style>
@media  print {
    .header-menu-area, .footer-copyright-area, .nav, .navbar, .mobile-menu-area { display: none !important; }
    body { margin: 0; padding: 0; }
    .container { width: 100%; max-width: none; padding: 0; margin: 0; }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
$('#partal_pdf').click(function() {
    html2canvas(document.querySelector('#partal_content')).then(canvas => {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const imgData = canvas.toDataURL('image/png');
        doc.addImage(imgData, 'PNG', 10, 10, 180, 0);
        doc.save('partal_report.pdf');
    });
});
$('#completion_pdf').click(function() {
    html2canvas(document.querySelector('#completion_content')).then(canvas => {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const imgData = canvas.toDataURL('image/png');
        doc.addImage(imgData, 'PNG', 10, 10, 180, 0);
        doc.save('completion_report.pdf');
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<style>
@media  print {
    .header-menu-area, .footer-copyright-area, .container { padding: 0; }
    .nav-tabs, .row.mb-3 { display: none !important; }
    .tab-content > div > h4 { display: block !important; text-align: center; margin-bottom: 20px; }
    #partal_table_container, #completion_table_container { display: block !important; margin: 0; }
    table { font-size: 12px; }
}
table { width: 100%; border-collapse: collapse; margin: 15px 0; font-size: 14px; }
table th, table td { border: 1px solid #ddd; padding: 10px; text-align: center; }
table th { background-color: #e9ecef; color: #333; font-weight: bold; }
tr:nth-child(even) { background-color: #f9f9f9; }
tr:nth-child(odd) { background-color: #fff; }
tr:hover { background-color: #f1f1f1; }
.value-cell { background-color: #d4edda !important; }

.tab-content .col-md-2{float:right;}
</style>
<div class="container" dir="rtl">
    <center><legend><h3>رپورٹس</h3></legend></center>

    <ul class="nav nav-tabs">
        <li class="active"><a data-toggle="tab" href="#partal">پڑتال رپورٹ</a></li>
        <li><a data-toggle="tab" href="#completion">تکمیلی کام رپورٹ</a></li>
    </ul>

    <div class="tab-content form-group" dir="rtl" style="width:100%;">
        <div id="partal" class="tab-pane fade in active" >

            <div id="" >
                <div class="col-md-2">
                    <label>تاریخ سے</label>
                    <input type="date" id="partal_from_date" class="form-control" value="<?php echo e($from_date); ?>">
                </div>
                <div class="col-md-2">
                    <label>تاریخ تک</label>
                    <input type="date" id="partal_to_date" class="form-control" value="<?php echo e($to_date); ?>">
                </div>
                <div class="col-md-2">
                    <label>ضلع</label>
                    <?php if($role_id == 1): ?>
                    <select id="partal_district_id" class="form-control" onchange="onDistrictChange(this.value, 'partal_tehsil_id')">
                        <option value="">تمام</option>
                        <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($district->districtId); ?>"><?php echo e($district->districtNameUrdu); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php else: ?>
                    <input type="hidden" id="partal_district_id" value="<?php echo e(session('zila_id')); ?>">
                    <input type="text" class="form-control" value="<?php echo e($zila_name); ?>" disabled>
                   
                   
                    <?php endif; ?>
                </div>
                <div class="col-md-2">
                    <label>تحصیل</label>
                    <?php if($role_id == 1): ?>
                    <select id="partal_tehsil_id" class="form-control" onchange="onTehsilChange(this.value, 'partal_moza_id')">
                        <option value="">تمام</option>
                    </select>
                    <?php else: ?>
                    <input type="hidden" id="partal_tehsil_id" value="<?php echo e(session('tehsil_id')); ?>">
                    <input type="text" class="form-control" value="<?php echo e($tehsil_name); ?>" disabled>
                  
                    <?php endif; ?>
                </div>
                <div class="col-md-2">
                    <label>موضع</label>
                    <select id="partal_moza_id" class="form-control">
                        <option value="">تمام</option>
                    </select>
                </div>
                <div class="col-md-2" style="padding-left:0;padding-right:0">
                    <br>
                    <button id="partal_filter" class="btn btn-primary btn-sm">فلٹر</button>
                    <button id="partal_pdf" type="button" class="btn btn-danger btn-sm">PDF</button>
                    <button id="partal_excel" type="button" class="btn btn-success btn-sm">Excel</button>
                    <button id="partal_print" type="button" class="btn btn-info btn-sm">Print</button>
                </div>
            </div>
            <div class="clearfix"></div>
            <div id="partal_content">
               <br>
                
             <center><h4>پڑتال رپورٹ</h4></center>
            <div id="partal_table_container">
                <table>
                    <thead>
                        <tr>
                            <th rowspan="2">سیریل نمبر</th>
                            <th colspan="7">بنیادی معلومات</th>
                            <th colspan="2">پڑتال پیمائش موقع</th>
                            <th colspan="2">تصدیق آخیر ملکیت وغیرہ بر موقع</th>
                            <th colspan="2">تصدیق آخیر شجرہ نسب</th>
                            <th colspan="2">تصدیق ملکیت و قبضہ کاشت وغیرہ</th>
                            <th rowspan="2">تبصرہ</th>
                        </tr>
                        <tr>
                            <th>ضلع نام</th>
                            <th>تحصیل نام</th>
                            <th>موضع نام</th>
                            <th>پٹواری نام</th>
                            <th>اہلکار نام</th>
                            <th>از تاریخ</th>
                            <th>تا تاریخ</th>
                            <th>تصدیق ملکیت/پیمود شدہ نمبرات خسرہ</th>
                            <th>تعداد برامدہ بدرات</th>
                            <th>تصدیق ملکیت و قبضہ کاشت نمبرات خسرہ</th>
                            <th>تعداد برامدہ بدرات</th>
                            <th>تعداد گھری</th>
                            <th>تعداد برامدہ بدرات</th>
                            <th>مقابلہ کھتونی ہمراہ کاپی چومنڈہ</th>
                            <th>تعداد برامدہ بدرات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $partal_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($item->districtNameUrdu); ?></td>
                            <td><?php echo e($item->tehsilNameUrdu); ?></td>
                            <td><?php echo e($item->mozaNameUrdu); ?></td>
                            <td><?php echo e($item->patwari_nam); ?></td>
                            <td><?php echo e($item->ahalkar_nam); ?></td>
                            <td><?php echo e($from_date); ?></td>
                            <td><?php echo e($to_date); ?></td>
                            <td class="<?php echo e($item->tasdeeq_milkiat_pemuda_khasra > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->tasdeeq_milkiat_pemuda_khasra == 0 ? '-' : $item->tasdeeq_milkiat_pemuda_khasra); ?></td>
                            <td class="<?php echo e($item->tasdeeq_milkiat_pemuda_khasra_badrat > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->tasdeeq_milkiat_pemuda_khasra_badrat == 0 ? '-' : $item->tasdeeq_milkiat_pemuda_khasra_badrat); ?></td>
                            <td class="<?php echo e($item->tasdeeq_milkiat_qabza_kasht_khasra > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->tasdeeq_milkiat_qabza_kasht_khasra == 0 ? '-' : $item->tasdeeq_milkiat_qabza_kasht_khasra); ?></td>
                            <td class="<?php echo e($item->tasdeeq_milkiat_qabza_kasht_badrat > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->tasdeeq_milkiat_qabza_kasht_badrat == 0 ? '-' : $item->tasdeeq_milkiat_qabza_kasht_badrat); ?></td>
                            <td class="<?php echo e($item->tasdeeq_shajra_nasab_guri > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->tasdeeq_shajra_nasab_guri == 0 ? '-' : $item->tasdeeq_shajra_nasab_guri); ?></td>
                            <td class="<?php echo e($item->tasdeeq_shajra_nasab_badrat > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->tasdeeq_shajra_nasab_badrat == 0 ? '-' : $item->tasdeeq_shajra_nasab_badrat); ?></td>
                            <td class="<?php echo e($item->muqabala_khatoni_chomanda > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->muqabala_khatoni_chomanda == 0 ? '-' : $item->muqabala_khatoni_chomanda); ?></td>
                            <td class="<?php echo e($item->muqabala_khatoni_chomanda_badrat > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->muqabala_khatoni_chomanda_badrat == 0 ? '-' : $item->muqabala_khatoni_chomanda_badrat); ?></td>
                            <td><?php echo e($item->tabsara); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

        <div id="completion" class="tab-pane fade">

            <div id="">
                <div class="col-md-2">
                    <label>تاریخ سے</label>
                    <input type="date" id="completion_from_date" class="form-control" value="<?php echo e($from_date); ?>">
                </div>
                <div class="col-md-2">
                    <label>تاریخ تک</label>
                    <input type="date" id="completion_to_date" class="form-control" value="<?php echo e($to_date); ?>">
                </div>
                <div class="col-md-2">
                    <label>ضلع</label>
                    <?php if($role_id == 1): ?>
                    <select id="completion_district_id" class="form-control" onchange="onDistrictChange(this.value, 'completion_tehsil_id')">
                        <option value="">تمام</option>
                        <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($district->districtId); ?>"><?php echo e($district->districtNameUrdu); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php else: ?>
                    <input type="hidden" id="completion_district_id" value="<?php echo e(session('zila_id')); ?>">
                      <input type="text" class="form-control" value="<?php echo e($zila_name); ?>" disabled>
                    
                    <?php endif; ?>
                </div>
                <div class="col-md-2">
                    <label>تحصیل</label>
                    <?php if($role_id == 1): ?>
                    <select id="completion_tehsil_id" class="form-control" onchange="onTehsilChange(this.value, 'completion_moza_id')">
                        <option value="">تمام</option>
                    </select>
                    <?php else: ?>
                    <input type="hidden" id="completion_tehsil_id" value="<?php echo e(session('tehsil_id')); ?>">
                    <input type="text" class="form-control" value="<?php echo e($tehsil_name); ?>" disabled>
                  
                    <?php endif; ?>
                </div>
                <div class="col-md-2">
                    <label>موضع</label>
                    <select id="completion_moza_id" class="form-control">
                        <option value="">تمام</option>
                    </select>
                </div>
                <div class="col-md-2" style="padding-left:0;padding-right:0">
                    <br>
                    <button id="completion_filter" class="btn btn-primary btn-sm">فلٹر</button>
                    <button id="completion_pdf" type="button" class="btn btn-danger btn-sm">PDF</button>
                    <button id="completion_excel" type="button" class="btn btn-success btn-sm">Excel</button>
                    <button id="completion_print" type="button" class="btn btn-info btn-sm">Print</button>
                </div>
            </div>
           
            <div id="completion_content">
              
                
            <div class="clearfix"></div>
             <br>
              <center><h4>تکمیلی کام رپورٹ</h4></center>
            <div id="completion_table_container">
                <table>
                    <thead>
                        <tr>
                            <th>نمبر شمار</th>
                            <th>نام ضلع</th>
                            <th>نام تحصیل</th>
                            <th>نام موضع</th>
                            <th>نام اہلکار</th>
                            <th>میزان کھاتہ دار/کھتونی</th>
                            <th>پختہ کھتونی درانڈکس خسرہ</th>
                            <th>درستی بدرات</th>
                            <th>تحریر نقل شجرہ نسب</th>
                            <th>تحریر شجرہ نسب مالکان قبضہ</th>
                            <th>پختہ کھاتاجات</th>
                            <th>خام کھاتہ جات در شجرہ نسب</th>
                            <th>تحریر مشترکہ کھاتہ</th>
                            <th>پختہ نمبرواں در کھتونی</th>
                            <th>خام نمبرواں در کھتونی</th>
                            <th>تصدیق آخیر</th>
                            <th>متفرق کام</th>
                            <th>از تاریخ</th>
                            <th>تا تاریخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $completion_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($item->districtNameUrdu); ?></td>
                            <td><?php echo e($item->tehsilNameUrdu); ?></td>
                            <td><?php echo e($item->mozaNameUrdu); ?></td>
                            <td><?php echo e($item->employee_name); ?> <?php if(!empty($item->employee_type_title)): ?><small>(<?php echo e($item->employee_type_title); ?>)</small><?php endif; ?></td>
                            <td class="<?php echo e($item->mizan_khata_dar_khatoni > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->mizan_khata_dar_khatoni == 0 ? '-' : $item->mizan_khata_dar_khatoni); ?></td>
                            <td class="<?php echo e($item->pukhta_khatoni_drandkas_khasra > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->pukhta_khatoni_drandkas_khasra == 0 ? '-' : $item->pukhta_khatoni_drandkas_khasra); ?></td>
                            <td class="<?php echo e($item->durusti_badrat > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->durusti_badrat == 0 ? '-' : $item->durusti_badrat); ?></td>
                            <td class="<?php echo e($item->tehreer_naqal_shajra_nasab > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->tehreer_naqal_shajra_nasab == 0 ? '-' : $item->tehreer_naqal_shajra_nasab); ?></td>
                            <td class="<?php echo e($item->tehreer_shajra_nasab_malkan_qabza > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->tehreer_shajra_nasab_malkan_qabza == 0 ? '-' : $item->tehreer_shajra_nasab_malkan_qabza); ?></td>
                            <td class="<?php echo e($item->pukhta_khatajat > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->pukhta_khatajat == 0 ? '-' : $item->pukhta_khatajat); ?></td>
                            <td class="<?php echo e($item->kham_khatajat_dar_shajra_nasab > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->kham_khatajat_dar_shajra_nasab == 0 ? '-' : $item->kham_khatajat_dar_shajra_nasab); ?></td>
                            <td class="<?php echo e($item->tehreer_mushtarka_khata > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->tehreer_mushtarka_khata == 0 ? '-' : $item->tehreer_mushtarka_khata); ?></td>
                            <td class="<?php echo e($item->pukhta_numberwan_dar_khatoni > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->pukhta_numberwan_dar_khatoni == 0 ? '-' : $item->pukhta_numberwan_dar_khatoni); ?></td>
                            <td class="<?php echo e($item->kham_numberwan_dar_khatoni > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->kham_numberwan_dar_khatoni == 0 ? '-' : $item->kham_numberwan_dar_khatoni); ?></td>
                            <td class="<?php echo e($item->tasdeeq_akhir > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->tasdeeq_akhir == 0 ? '-' : $item->tasdeeq_akhir); ?></td>
                            <td class="<?php echo e($item->mutafarriq_kaam > 0 ? 'value-cell' : ''); ?>"><?php echo e($item->mutafarriq_kaam == 0 ? '-' : $item->mutafarriq_kaam); ?></td>
                            <td><?php echo e($from_date); ?></td>
                            <td><?php echo e($to_date); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
</div>
</div>

<script>
$(document).ready(function() {
    loadPartalReports();
    loadCompletionReports();

    // Load moza options for role_id 2
    if ($('#partal_tehsil_id').is('input:hidden')) {
        onTehsilChange($('#partal_tehsil_id').val(), 'partal_moza_id');
    }
    if ($('#completion_tehsil_id').is('input:hidden')) {
        onTehsilChange($('#completion_tehsil_id').val(), 'completion_moza_id');
    }

    $('#partal_filter').click(function() {
        loadPartalReports();
    });

    $('#completion_filter').click(function() {
        loadCompletionReports();
    });

    $('#partal_print').click(function() {
        window.print();
    });

    $('#completion_print').click(function() {
        window.print();
    });

   
});

function getPartalFilters() {
    return 'from_date=' + $('#partal_from_date').val() + '&to_date=' + $('#partal_to_date').val() + '&district_id=' + $('#partal_district_id').val() + '&tehsil_id=' + $('#partal_tehsil_id').val() + '&moza_id=' + $('#partal_moza_id').val();
}

function getCompletionFilters() {
    return 'from_date=' + $('#completion_from_date').val() + '&to_date=' + $('#completion_to_date').val() + '&district_id=' + $('#completion_district_id').val() + '&tehsil_id=' + $('#completion_tehsil_id').val() + '&moza_id=' + $('#completion_moza_id').val();
}

function loadPartalReports() {
    $.get('<?php echo e(route("reports.partal")); ?>', getPartalFilters(), function(data) {
        let html = '<table><thead><tr><th rowspan="2">سیریل نمبر</th><th colspan="7">بنیادی معلومات</th><th colspan="2">پڑتال پیمائش موقع</th><th colspan="2">تصدیق آخیر ملکیت وغیرہ بر موقع</th><th colspan="2">تصدیق آخیر شجرہ نسب</th><th colspan="2">تصدیق ملکیت و قبضہ کاشت وغیرہ</th><th rowspan="2">تبصرہ</th></tr><tr><th>ضلع نام</th><th>تحصیل نام</th><th>موضع نام</th><th>پٹواری نام</th><th>اہلکار نام</th><th>از تاریخ</th><th>تا تاریخ</th><th>تصدیق ملکیت/پیمود شدہ نمبرات خسرہ</th><th>تعداد برامدہ بدرات</th><th>تصدیق ملکیت و قبضہ کاشت نمبرات خسرہ</th><th>تعداد برامدہ بدرات</th><th>تعداد گھری</th><th>تعداد برامدہ بدرات</th><th>مقابلہ کھتونی ہمراہ کاپی چومنڈہ</th><th>تعداد برامدہ بدرات</th></tr></thead><tbody>';
        data.forEach(function(item, index) {
            html += '<tr><td>' + (index + 1) + '</td><td>' + item.districtNameUrdu + '</td><td>' + item.tehsilNameUrdu + '</td><td>' + item.mozaNameUrdu + '</td><td>' + item.patwari_nam + '</td><td>' + item.ahalkar_nam + '</td><td>' + $('#partal_from_date').val() + '</td><td>' + $('#partal_to_date').val() + '</td><td class="' + (item.tasdeeq_milkiat_pemuda_khasra > 0 ? 'value-cell' : '') + '">' + (item.tasdeeq_milkiat_pemuda_khasra == 0 ? '-' : item.tasdeeq_milkiat_pemuda_khasra) + '</td><td class="' + (item.tasdeeq_milkiat_pemuda_khasra_badrat > 0 ? 'value-cell' : '') + '">' + (item.tasdeeq_milkiat_pemuda_khasra_badrat == 0 ? '-' : item.tasdeeq_milkiat_pemuda_khasra_badrat) + '</td><td class="' + (item.tasdeeq_milkiat_qabza_kasht_khasra > 0 ? 'value-cell' : '') + '">' + (item.tasdeeq_milkiat_qabza_kasht_khasra == 0 ? '-' : item.tasdeeq_milkiat_qabza_kasht_khasra) + '</td><td class="' + (item.tasdeeq_milkiat_qabza_kasht_badrat > 0 ? 'value-cell' : '') + '">' + (item.tasdeeq_milkiat_qabza_kasht_badrat == 0 ? '-' : item.tasdeeq_milkiat_qabza_kasht_badrat) + '</td><td class="' + (item.tasdeeq_shajra_nasab_guri > 0 ? 'value-cell' : '') + '">' + (item.tasdeeq_shajra_nasab_guri == 0 ? '-' : item.tasdeeq_shajra_nasab_guri) + '</td><td class="' + (item.tasdeeq_shajra_nasab_badrat > 0 ? 'value-cell' : '') + '">' + (item.tasdeeq_shajra_nasab_badrat == 0 ? '-' : item.tasdeeq_shajra_nasab_badrat) + '</td><td class="' + (item.muqabala_khatoni_chomanda > 0 ? 'value-cell' : '') + '">' + (item.muqabala_khatoni_chomanda == 0 ? '-' : item.muqabala_khatoni_chomanda) + '</td><td class="' + (item.muqabala_khatoni_chomanda_badrat > 0 ? 'value-cell' : '') + '">' + (item.muqabala_khatoni_chomanda_badrat == 0 ? '-' : item.muqabala_khatoni_chomanda_badrat) + '</td><td>' + item.tabsara + '</td></tr>';
        });
        html += '</tbody></table>';
        $('#partal_table_container').html(html);
    });
}

function loadCompletionReports() {
    $.get('<?php echo e(route("reports.completion_process")); ?>', getCompletionFilters(), function(data) {
        let html = '<table><thead><tr><th>نمبر شمار</th><th>نام ضلع</th><th>نام تحصیل</th><th>نام موضع</th><th>نام اہلکار</th><th>میزان کھاتہ دار/کھتونی</th><th>پختہ کھتونی درانڈکس خسرہ</th><th>درستی بدرات</th><th>تحریر نقل شجرہ نسب</th><th>تحریر شجرہ نسب مالکان قبضہ</th><th>پختہ کھاتاجات</th><th>خام کھاتہ جات در شجرہ نسب</th><th>تحریر مشترکہ کھاتہ</th><th>پختہ نمبرواں در کھتونی</th><th>خام نمبرواں در کھتونی</th><th>تصدیق آخیر</th><th>متفرق کام</th><th>از تاریخ</th><th>تا تاریخ</th></tr></thead><tbody>';
        data.forEach(function(item, index) {
            html += '<tr><td>' + (index + 1) + '</td><td>' + item.districtNameUrdu + '</td><td>' + item.tehsilNameUrdu + '</td><td>' + item.mozaNameUrdu + '</td><td>' + item.employee_name + (item.employee_type_title ? ' <small>(' + item.employee_type_title + ')</small>' : '') + '</td><td class="' + (item.mizan_khata_dar_khatoni > 0 ? 'value-cell' : '') + '">' + (item.mizan_khata_dar_khatoni == 0 ? '-' : item.mizan_khata_dar_khatoni) + '</td><td class="' + (item.pukhta_khatoni_drandkas_khasra > 0 ? 'value-cell' : '') + '">' + (item.pukhta_khatoni_drandkas_khasra == 0 ? '-' : item.pukhta_khatoni_drandkas_khasra) + '</td><td class="' + (item.durusti_badrat > 0 ? 'value-cell' : '') + '">' + (item.durusti_badrat == 0 ? '-' : item.durusti_badrat) + '</td><td class="' + (item.tehreer_naqal_shajra_nasab > 0 ? 'value-cell' : '') + '">' + (item.tehreer_naqal_shajra_nasab == 0 ? '-' : item.tehreer_naqal_shajra_nasab) + '</td><td class="' + (item.tehreer_shajra_nasab_malkan_qabza > 0 ? 'value-cell' : '') + '">' + (item.tehreer_shajra_nasab_malkan_qabza == 0 ? '-' : item.tehreer_shajra_nasab_malkan_qabza) + '</td><td class="' + (item.pukhta_khatajat > 0 ? 'value-cell' : '') + '">' + (item.pukhta_khatajat == 0 ? '-' : item.pukhta_khatajat) + '</td><td class="' + (item.kham_khatajat_dar_shajra_nasab > 0 ? 'value-cell' : '') + '">' + (item.kham_khatajat_dar_shajra_nasab == 0 ? '-' : item.kham_khatajat_dar_shajra_nasab) + '</td><td class="' + (item.tehreer_mushtarka_khata > 0 ? 'value-cell' : '') + '">' + (item.tehreer_mushtarka_khata == 0 ? '-' : item.tehreer_mushtarka_khata) + '</td><td class="' + (item.pukhta_numberwan_dar_khatoni > 0 ? 'value-cell' : '') + '">' + (item.pukhta_numberwan_dar_khatoni == 0 ? '-' : item.pukhta_numberwan_dar_khatoni) + '</td><td class="' + (item.kham_numberwan_dar_khatoni > 0 ? 'value-cell' : '') + '">' + (item.kham_numberwan_dar_khatoni == 0 ? '-' : item.kham_numberwan_dar_khatoni) + '</td><td class="' + (item.tasdeeq_akhir > 0 ? 'value-cell' : '') + '">' + (item.tasdeeq_akhir == 0 ? '-' : item.tasdeeq_akhir) + '</td><td class="' + (item.mutafarriq_kaam > 0 ? 'value-cell' : '') + '">' + (item.mutafarriq_kaam == 0 ? '-' : item.mutafarriq_kaam) + '</td><td>' + $('#completion_from_date').val() + '</td><td>' + $('#completion_to_date').val() + '</td></tr>';
        });
        html += '</tbody></table>';
        $('#completion_table_container').html(html);
    });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms\resources\views/reports/index.blade.php ENDPATH**/ ?>