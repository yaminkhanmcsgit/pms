

<?php $__env->startSection('title', 'پارٹل ریکارڈ'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" dir="rtl">
    <style>
        thead th {
            border:1px solid #ddd8d8 !important;
        }
        @media  print { .no-print { display: none; } }
    </style>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="<?php echo e(route('partal.create')); ?>" class="btn btn-success">
            <i class="fa fa-plus"></i> نیا ریکارڈ شامل کریں
        </a>
        <center><h3 class="mb-0">گوشوارہ پڑتال رپورٹ</h3></center>
    </div>

    <div class="table-responsive">
        <table class="table table-striped table-hover table-bordered text-center">
            <thead class="thead-dark">
                <tr>
                    <th rowspan="2">سیریل نمبر</th>
                    <th colspan="6">بنیادی معلومات</th>
                    <th colspan="2">پڑتال پیمائش موقع</th>
                    <th colspan="2">تصدیق آخیر ملکیت وغیرہ بر موقع</th>
                    <th colspan="2">تصدیق آخیر شجرہ نسب</th>
                    <th colspan="2">تصدیق ملکیت و قبضہ کاشت وغیرہ</th>
                    <th rowspan="2">تبصرہ</th>
                    <th rowspan="2">عمل</th>
                </tr>
                <tr>
                    <th>ضلع نام</th>
                    <th>تحصیل نام</th>
                    <th>موضع نام</th>
                    <th>پٹوار نام</th>
                    <th>اہلکار نام</th>
                    <th>تاریخ پڑتال</th>
                    <th>تصدیق ملکیت/پیمود شدہ نمبرات خسرہ</th>
                    <th>تعداد برامدہ بدرات</th>
                    <th>تصدیق ملکیت و قبضہ کاشت نمبرات خسرہ</th>
                    <th>تعداد برامدہ بدرات</th>
                    <th>تعداد گھری</th>
                    <th>تعداد برامدہ بدرات</th>
                    <th>مقابلہ کھتونی ہمراہ کاپی چومنڈہ</th>
                    <th>تعداد برامدہ بدرات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($rec->id); ?></td>
                    <td><?php echo e($rec->districtNameUrdu); ?></td>
                    <td><?php echo e($rec->tehsilNameUrdu); ?></td>
                    <td><?php echo e($rec->mozaNameUrdu); ?></td>
                    <td><?php echo e($rec->patwari_nam); ?> <?php echo e($rec->patwari_title); ?></td>
                    <td><?php echo e($rec->ahalkar_nam); ?> <?php echo e($rec->ahalkar_title); ?></td>
                    <td class="date-cell"><?php echo e($rec->tareekh_partal ? date('d-m-Y', strtotime($rec->tareekh_partal)) : ''); ?></td>
                    <td><?php echo e($rec->tasdeeq_milkiat_pemuda_khasra); ?></td>
                    <td><?php echo e($rec->tasdeeq_milkiat_pemuda_khasra_badrat); ?></td>
                    <td><?php echo e($rec->tasdeeq_milkiat_qabza_kasht_khasra); ?></td>
                    <td><?php echo e($rec->tasdeeq_milkiat_qabza_kasht_badrat); ?></td>
                    <td><?php echo e($rec->tasdeeq_shajra_nasab_guri); ?></td>
                    <td><?php echo e($rec->tasdeeq_shajra_nasab_badrat); ?></td>
                    <td><?php echo e($rec->muqabala_khatoni_chomanda); ?></td>
                    <td><?php echo e($rec->muqabala_khatoni_chomanda_badrat); ?></td>
                    <td><?php echo e($rec->tabsara); ?></td>
                    <td>
                        <a href="<?php echo e(route('partal.edit', $rec->id)); ?>" class="btn btn-sm btn-warning">
                            <i class="fa fa-edit"></i> ترمیم
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-center">
            <?php echo e($records->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms\resources\views/partal/index.blade.php ENDPATH**/ ?>