


<?php $__env->startSection('title', 'نیا صارف شامل کریں'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" >
    <center><legend><h3>نیا صارف شامل کریں</h3></legend></center>
    <form action="<?php echo e(route('operators.store')); ?>" method="POST" class="form-modern" >
        <?php echo csrf_field(); ?>
        <div class="row">
           
           
            
            <div class="form-group col-md-4 col-12">
                <label>مکمل نام</label>
                <input type="text" name="full_name" class="form-control" required>
            </div>
             <div class="form-group col-md-4 col-12">
                <label>صارف نام</label>
                <input type="text" name="username" class="form-control" required>
            </div>
             <div class="form-group col-md-4 col-12">
                <label>پاس ورڈ</label>
                <input type="password" name="password" class="form-control" required>
            </div>
        </div>
        <div class="row">
             <div class="form-group col-md-6 col-12">
                 <label>ضلع</label>
                 <?php if($role_id == 1): ?>
                 <select name="zila_id" id="zila_id" class="form-control" required onchange="onDistrictChange(this.value, 'tehsil_id')">
                     <option value="">منتخب کریں</option>
                     <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($district->districtId); ?>"><?php echo e($district->districtNameUrdu); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
                 <?php else: ?>
                 <input type="hidden" name="zila_id" value="<?php echo e($districts->first()->districtId); ?>">
                 <input type="text" class="form-control" value="<?php echo e($districts->first()->districtNameUrdu); ?>" readonly>
                 <?php endif; ?>
             </div>
             <div class="form-group col-md-6 col-12">
                 <label>تحصیل</label>
                 <?php if($role_id == 1): ?>
                 <select name="tehsil_id" id="tehsil_id" class="form-control" required>
                     <option value="">منتخب کریں</option>
                     <?php $__currentLoopData = $tehsils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tehsil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($tehsil->tehsilId); ?>"><?php echo e($tehsil->tehsilNameUrdu); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
                 <?php else: ?>
                 <input type="hidden" name="tehsil_id" value="<?php echo e($tehsils->first()->tehsilId); ?>">
                 <input type="text" class="form-control" value="<?php echo e($tehsils->first()->tehsilNameUrdu); ?>" readonly>
                 <?php endif; ?>
             </div>
           
        </div>
        
        <div class="row">
            <div class="form-group col-md-6 col-xs-12">
                <label class="control-label" style="float: right; text-align: right;">رول</label>
                <select name="role_id" class="form-control" style="direction: rtl; text-align: right;">
                    <option value="">منتخب کریں</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->role_id); ?>"><?php echo e($role->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <br>
        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> محفوظ کریں</button>
        <a href="<?php echo e(route('operators.index')); ?>" class="btn btn-secondary">واپس</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms\resources\views/operators/create.blade.php ENDPATH**/ ?>