

<?php $__env->startSection('title', 'ملازمین'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" dir="rtl">
    <div class="d-flex justify-content-between align-items-center mb-3">
       
        <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-success">
            <i class="fa fa-plus"></i> ملازم شامل کریں
        </a>
    </div>
    
    <center><legend> <h3>ملازمین کی فہرست</h3></legend></center>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="thead-dark text-center">
                <tr>
                    <th>نمبر شمار</th>
                    <th>نام</th>
                    <th>والد کا نام</th>
                    <th>نام ضلع</th>
                    <th>نام تحصیل</th>
                    <th>نام موضع</th>
                    <th>فون</th>
                    <th>شناختی کارڈ</th>
                    <th>تعلیم</th>
                    <th>اہلکار کی قسم</th>
                    <th>تاریخ شمولیت</th>
                    <th class="no-print">عمل</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($emp->id); ?></td>
                    <td><?php echo e($emp->nam); ?></td>
                    <td><?php echo e($emp->walid_ka_nam); ?></td>
                    <td><?php echo e($emp->district_name); ?></td>
                    <td><?php echo e($emp->tehsil_name); ?></td>
                    <td><?php echo e($emp->moza_name); ?></td>
                    <td><?php echo e($emp->phone); ?></td>
                    <td><?php echo e($emp->cnic); ?></td>
                    <td><?php echo e($emp->darja_taleem); ?></td>
                    <td><?php echo e($emp->employee_type_title); ?></td>
                    <td><?php echo e($emp->tareekh_shamil ? date('d-m-Y', strtotime($emp->tareekh_shamil)) : ''); ?></td>
                    <td>
                        <a href="<?php echo e(route('employees.edit', $emp->id)); ?>" class="btn btn-sm btn-warning">
                            <i class="fa fa-edit"></i> ترمیم
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms\resources\views/employees/index.blade.php ENDPATH**/ ?>