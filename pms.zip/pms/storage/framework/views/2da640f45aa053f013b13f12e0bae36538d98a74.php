<div class="sidebar">
    <ul class="nav">
        <li><a href="<?php echo e(route('operators.index')); ?>">Operators</a></li>
        <li><a href="#">Employees</a></li>
        <li><a href="#">Completion Process</a></li>
        <li><a href="#">Partal</a></li>
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\pms\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>