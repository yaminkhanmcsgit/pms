<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Land Record System</a>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\pms\resources\views/layouts/header.blade.php ENDPATH**/ ?>