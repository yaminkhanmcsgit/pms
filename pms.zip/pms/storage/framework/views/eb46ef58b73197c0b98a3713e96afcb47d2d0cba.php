

<?php $__env->startSection('title', 'Grievances'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" dir="ltr">
    <div class="mb-3">

        <a href="<?php echo e(route('grievances.create')); ?>" class="btn btn-success pull-right">
            <i class="fa fa-plus"></i> Add New Grievance
        </a>
    </div>

    <center><legend> <h3>Grievances List</h3></legend></center>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Applicant Name</th>
                    <th>Father Name</th>
                    <th>CNIC</th>
                    <th>District</th>
                    <th>Tehsil</th>
                    <th>Mouza</th>
                    <th>Grievance Type</th>
                    <th>Status</th>
                    <th>Application Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $grievances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grievance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($grievance->id); ?></td>
                    <td><?php echo e($grievance->applicant_name); ?></td>
                    <td><?php echo e($grievance->father_name); ?></td>
                    <td><?php echo e($grievance->cnic); ?></td>
                    <td><?php echo e($grievance->district_name); ?></td>
                    <td><?php echo e($grievance->tehsil_name); ?></td>
                    <td><?php echo e($grievance->moza_name); ?></td>
                    <td><?php echo e($grievance->grievance_type_name); ?></td>
                    <td><span class="label label-<?php echo e($grievance->status_color); ?>"><?php echo e($grievance->status_name); ?></span></td>
                    <td><?php echo e($grievance->application_date ? date('d-m-Y', strtotime($grievance->application_date)) : ''); ?></td>
                    <td>
                        <button class="btn btn-sm btn-info" onclick="viewGrievance(<?php echo e($grievance->id); ?>)">
                            <i class="fa fa-eye"></i> View
                        </button>
                        <a href="<?php echo e(route('grievances.edit', $grievance->id)); ?>" class="btn btn-sm btn-warning">
                            <i class="fa fa-edit"></i> Edit
                        </a>
                        <form action="<?php echo e(route('grievances.destroy', $grievance->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                <i class="fa fa-trash"></i> Delete
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="11" class="text-center">No grievances found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($grievances->links()); ?>


    <!-- Grievance Details Modal -->
    <div class="modal fade" id="grievanceModal" tabindex="-1" role="dialog" aria-labelledby="grievanceModalLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title" id="grievanceModalLabel">Grievance Details & Processing</h4>
                </div>
                <div class="modal-body" id="grievanceDetails">
                    <!-- Grievance details will be loaded here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    .form-group {
        float: left;width:100%;
    }
</style>
<script>
function populateModalDropdowns(grievance) {
    // Use existing global functions from app.blade.php
    // First populate districts
    fetch(`<?php echo e(url('api/districts')); ?>`)
        .then(res => res.json())
        .then(districts => {
            const districtDropdown = document.getElementById('modal_district');
            districtDropdown.innerHTML = '<option value="">Select District</option>';
            districts.forEach(district => {
                const selected = grievance.district == district.zila_id ? 'selected' : '';
                districtDropdown.innerHTML += `<option value="${district.zila_id}" ${selected}>${district.zilaNameUrdu}</option>`;
            });

            // Then populate dependent dropdowns using existing global functions
            if (grievance.district) {
                onDistrictChange(grievance.district, 'modal_tehsil', grievance.tehsil);
                if (grievance.tehsil) {
                    // Small delay to ensure tehsils are populated first
                    setTimeout(() => {
                        onTehsilChange(grievance.tehsil, 'modal_moza', grievance.village_name);
                    }, 100);
                }
            }
        });
}

function viewGrievance(id) {
    // Fetch grievance details and types/statuses via AJAX
    Promise.all([
        fetch(`<?php echo e(url('grievances')); ?>/${id}`).then(response => response.json()),
        fetch(`<?php echo e(url('grievance-types')); ?>`).then(response => response.json()),
        fetch(`<?php echo e(url('grievance-statuses')); ?>`).then(response => response.json())
    ])
    .then(([grievanceData, typesData, statusesData]) => {
        if (grievanceData.success) {
            displayGrievanceDetails(grievanceData.grievance, typesData.types || [], statusesData.statuses || []);
        } else {
            alert('Error: ' + (grievanceData.message || 'Unable to load grievance details'));
        }
    })
    .catch(error => {
        console.error('Error fetching data:', error);
        alert('Error loading grievance details');
    });
}

function displayGrievanceDetails(grievance, types, statuses) {
    // Set the HTML first
    const detailsHtml = `
        <div class="text-center" style="margin-bottom:20px;">
            <h4><strong>GOVERNMENT OF KHYBER PAKHTUNKHWA</strong></h4>
            <h5>BOARD OF REVENUE KHYBER PAKHTUNKHWA</h5>
            <h5>SETTLEMENT OF LAND RECORDS DIR/KALAM PROJECT</h5>
        </div>
        <form id="statusUpdateForm">
        <div class="row" style="margin-bottom:20px;">
            <div class="col-md-6">
                <label>District:</label>
                <select name="district_id" id="modal_district" class="form-control" onchange="onDistrictChange(this.value, 'modal_tehsil')">
                    <option value="">Select District</option>
                    <!-- Districts will be populated via JavaScript -->
                </select>
            </div>
            <div class="col-md-6">
                <label>Tehsil:</label>
                <select name="tehsil_id" id="modal_tehsil" class="form-control" onchange="onTehsilChange(this.value, 'modal_moza')">
                    <option value="">Select Tehsil</option>
                </select>
            </div>
        </div>

        <h4 style="margin-bottom:20px;">
            <strong>PROFORMA FOR REDRESSAL OF APPLICATION / GRIEVANCE DURING LAND SETTLEMENT OPERATIONS</strong>
        </h4>

        <table class="table table-bordered">
            <tr>
                <td style="width:30%;">1. Name of Applicant:</td>
                <td><input type="text" name="applicant_name" class="form-control" value="${grievance.applicant_name || ''}"></td>
            </tr>
            <tr>
                <td>2. Father's Name:</td>
                <td><input type="text" name="father_name" class="form-control" value="${grievance.father_name || ''}"></td>
            </tr>
            <tr>
                <td>3. CNIC No.:</td>
                <td><input type="text" name="cnic" class="form-control" value="${grievance.cnic || ''}"></td>
            </tr>
            <tr>
                <td>4. Address / Contact No.:</td>
                <td><input type="text" name="address" class="form-control" value="${grievance.address || ''}"></td>
            </tr>
            <tr>
                <td>5. Mouza / Village Name:</td>
                <td>
                    <select name="moza_id" id="modal_moza" class="form-control">
                        <option value="">Select Mouza</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>6. Nature of Grievance / Application:</td>
                <td><input type="text" name="nature_of_grievance" class="form-control" value="${grievance.nature_of_grievance || ''}"></td>
            </tr>
        </table>

        <div style="margin-left:10px; margin-bottom:20px;">
            <label>Grievance Type:</label>
            <select name="grievance_type_id" class="form-control">
                <option value="">Select Type</option>
                ${types.map(type => `<option value="${type.id}" ${grievance.grievance_type_id == type.id ? 'selected' : ''}>${type.name}</option>`).join('')}
            </select>
        </div>
        <hr>
        
            <input type="hidden" name="grievance_id" value="${grievance.id}">

           
                <div class="col-md-12">
                    <div class="form-group" >
                        <label style="margin-right: 10px; min-width: 200px;">7. Brief Description of Grievance</label>
                        <div >
                            <textarea name="grievance_description" class="form-control" rows="2" style="display: inline-block; width: 100%;">${grievance.grievance_description || ''}</textarea>
                            <em style="display: block; font-size: 0.9em;">(Attach additional sheets if required)</em>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group" >
                        <label style="margin-right: 10px; min-width: 120px;">8. Date of Receipt</label>
                        <input type="date" name="application_date" class="form-control"  value="${grievance.application_date ? new Date(grievance.application_date).toISOString().split('T')[0] : ''}">
                    </div>
                   
                </div>
                 <div class="col-md-12">
                 <div class="form-group" >
                        <label style="margin-right: 10px; min-width: 120px;">9. Forwarded by</label>
                        <input type="text" name="forwarded_by" class="form-control"  value="${grievance.forwarded_by || ''}" placeholder="Settlement Patwari / Girdawar / ASO">
                    </div>
                    </div>
           

            <h4><strong>Action by Tehsildar (Settlement)</strong></h4>

           
                <div class="col-md-12">
                    <div class="form-group" >
                        <label style="margin-right: 10px; min-width: 140px;">10. Date of Receipt By Tehsildar</label>
                        <input type="date" name="received_by_tehsildar_date" class="form-control"  value="${grievance.received_by_tehsildar_date ? new Date(grievance.received_by_tehsildar_date).toISOString().split('T')[0] : ''}">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group" >
                        <label style="margin-right: 10px; min-width: 160px;">13. Field Verification Date</label>
                        <input type="date" name="field_verification_date" class="form-control"  value="${grievance.field_verification_date ? new Date(grievance.field_verification_date).toISOString().split('T')[0] : ''}">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group" >
                        <label style="margin-right: 10px; min-width: 130px;">15. Date of Disposal</label>
                        <input type="date" name="disposal_date" class="form-control"  value="${grievance.disposal_date ? new Date(grievance.disposal_date).toISOString().split('T')[0] : ''}">
                    </div>
                </div>
            

           
                <div class="col-md-12">
                    <div class="form-group" >
                        <label style="margin-right: 10px; min-width: 150px;">11. Preliminary Remarks</label>
                        <textarea name="preliminary_remarks" class="form-control" rows="2" >${grievance.preliminary_remarks || ''}</textarea>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group" >
                        <label style="margin-right: 10px; min-width: 140px;">12. Action Proposed</label>
                        <textarea name="action_proposed" class="form-control" rows="2" >${grievance.action_proposed || ''}</textarea>
                    </div>
                </div>
           

          
                <div class="col-md-12">
                    <div class="form-group" >
                        <label style="margin-right: 10px; min-width: 160px;">14. Decision / Redressal</label>
                        <textarea name="decision" class="form-control" rows="2" >${grievance.decision || ''}</textarea>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group" >
                        <label style="margin-right: 10px; min-width: 180px;">17. Assistant Officer Remarks</label>
                        <textarea name="assistant_remarks" class="form-control" rows="2" >${grievance.assistant_remarks || ''}</textarea>
                    </div>
                </div>
           

            
                <div class="col-md-12">
                    <div class="form-group" >
                        <label style="margin-right: 10px; min-width: 160px;">16. Tehsildar Signature</label>
                        <input type="text" name="tehsildar_signature" class="form-control"  value="${grievance.tehsildar_signature || ''}">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group" >
                        <label style="margin-right: 10px; min-width: 60px;">Status</label>
                        <select name="status_id" class="form-control" >
                            <option value="">Select Status</option>
                            ${statuses.map(status => `<option value="${status.id}" ${grievance.status_id == status.id ? 'selected' : ''}>${status.name}</option>`).join('')}
                        </select>
                    </div>
                </div>
           

            <div class="text-center">
                <button type="submit" class="btn btn-success btn-lg">Update Status & Details</button>
            </div>
        </form>
    `;
    document.getElementById('grievanceDetails').innerHTML = detailsHtml;

    // Now populate dropdowns
    populateModalDropdowns(grievance);

    // Show modal after dropdowns are populated
    $('#grievanceModal').modal('show');

    // Handle status update form submission
    document.getElementById('statusUpdateForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);

        // Get selected grievance type
        const grievanceTypeId = formData.get('grievance_type_id');

        fetch(`/grievances/${grievance.id}/update-status`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status_id: formData.get('status_id'),
                district_id: formData.get('district_id'),
                tehsil_id: formData.get('tehsil_id'),
                moza_id: formData.get('moza_id'),
                applicant_name: formData.get('applicant_name'),
                father_name: formData.get('father_name'),
                cnic: formData.get('cnic'),
                address: formData.get('address'),
                moza_name: formData.get('moza_name'),
                nature_of_grievance: formData.get('nature_of_grievance'),
                grievance_type_id: grievanceTypeId,
                grievance_description: formData.get('grievance_description'),
                application_date: formData.get('application_date'),
                forwarded_by: formData.get('forwarded_by'),
                received_by_tehsildar_date: formData.get('received_by_tehsildar_date'),
                preliminary_remarks: formData.get('preliminary_remarks'),
                action_proposed: formData.get('action_proposed'),
                field_verification_date: formData.get('field_verification_date'),
                decision: formData.get('decision'),
                disposal_date: formData.get('disposal_date'),
                tehsildar_signature: formData.get('tehsildar_signature'),
                assistant_remarks: formData.get('assistant_remarks')
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Status updated successfully!');
                $('#grievanceModal').modal('hide');
                location.reload();
            } else {
                alert('Error: ' + (data.message || 'Unable to update status'));
            }
        })
        .catch(error => {
            console.error('Error updating status:', error);
            alert('Error updating status');
        });
    });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms\resources\views/grievances/index.blade.php ENDPATH**/ ?>