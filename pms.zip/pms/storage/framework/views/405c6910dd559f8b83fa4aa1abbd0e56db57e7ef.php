

<?php $__env->startSection('title', 'Add New Grievance'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" dir="ltr" style="max-width: 800px;margin: 0 auto;background: #fff;">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <style>
    .form-group {
        float: left;width:100%;
    }
</style>
    <div class="text-center" style="margin-bottom:20px;">
        <h4><strong>GOVERNMENT OF KHYBER PAKHTUNKHWA</strong></h4>
        <h5>BOARD OF REVENUE KHYBER PAKHTUNKHWA</h5>
        <h5>SETTLEMENT OF LAND RECORDS DIR/KALAM PROJECT</h5>
    </div>

    <form action="<?php echo e(route('grievances.store')); ?>" method="POST" class="form-modern">
        <?php echo csrf_field(); ?>

        <div class="row" style="margin-bottom:20px;">
            <div class="col-xs-6">
                <strong>District:</strong>
                <select name="district_id" id="zila_id" class="form-control" required onchange="onDistrictChange(this.value, 'tehsil_id')" style="display: inline-block; width: 60%;">
                    <option value="">Select District</option>
                </select>
            </div>
            <div class="col-xs-6">
                <strong>Tehsil:</strong>
                <select name="tehsil_id" id="tehsil_id" class="form-control" required onchange="onTehsilChange(this.value, 'moza_id')" style="display: inline-block; width: 60%;">
                    <option value="">Select Tehsil</option>
                </select>
            </div>
        </div>

        <h4 style="margin-bottom:20px;">
            <strong>PROFORMA FOR REDRESSAL OF APPLICATION / GRIEVANCE DURING LAND SETTLEMENT OPERATIONS</strong>
        </h4>

        <table class="table table-bordered">
            <tr>
                <td style="width:30%;">1. Name of Applicant:</td>
                <td><input type="text" name="applicant_name" class="form-control urdu-input" required style="direction: rtl; text-align: right; font-family: 'Noto Nastaleeq Urdu', 'Jameel Noori Nastaleeq', 'Nafees', sans-serif;" onfocus="ActivateUrdu(this)"></td>
            </tr>
            <tr>
                <td>2. Father's Name:</td>
                <td><input type="text" name="father_name" class="form-control urdu-input" required style="direction: rtl; text-align: right; font-family: 'Noto Nastaleeq Urdu', 'Jameel Noori Nastaleeq', 'Nafees', sans-serif;" onfocus="ActivateUrdu(this)"></td>
            </tr>
            <tr>
                <td>3. CNIC No.:</td>
                <td><input type="text" name="cnic" class="form-control" required></td>
            </tr>
            <tr>
                <td>4. Address / Contact No.:</td>
                <td><input type="text" name="address" class="form-control urdu-input" style="direction: rtl; text-align: right; font-family: 'Noto Nastaleeq Urdu', 'Jameel Noori Nastaleeq', 'Nafees', sans-serif;" onfocus="ActivateUrdu(this)"></td>
            </tr>
            <tr>
                <td>5. Mouza / Village Name:</td>
                <td>
                    <select name="moza_id" id="moza_id" class="form-control" required>
                        <option value="">Select Mouza</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>6. Nature of Grievance / Application:</td>
                <td><input type="text" name="nature_of_grievance" class="form-control urdu-input" style="direction: rtl; text-align: right; font-family: 'Noto Nastaleeq Urdu', 'Jameel Noori Nastaleeq', 'Nafees', sans-serif;" onfocus="ActivateUrdu(this)"></td>
            </tr>
        </table>

        <div style="margin-left:10px; margin-bottom:20px;">
            <label>Grievance Type:</label>
            <select name="grievance_type_id" class="form-control">
                <option value="">Select Type</option>
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label>7. Brief Description of Grievance:</label>
            <textarea name="grievance_description" class="form-control urdu-input" rows="4" style="direction: rtl; text-align: right; font-family: 'Noto Nastaleeq Urdu', 'Jameel Noori Nastaleeq', 'Nafees', sans-serif;" onfocus="ActivateUrdu(this)"></textarea>
            <em>(Attach additional sheets if required)</em>
        </div>

        <div class="form-group">
            <label>8. Date of Receipt of Application:</label>
            <input type="date" name="application_date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required>
        </div>

        <div class="form-group">
            <label>Status:</label>
            <select name="status_id" class="form-control" required>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="text-center">
            <button type="submit" class="btn btn-success btn-lg">Submit Grievance</button>
        </div>
    </form>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(url('public/js/urdutextbox.js')); ?>"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.urdu-input').forEach(function(input) {
        ActivateUrdu(input);
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms\resources\views/grievances/create.blade.php ENDPATH**/ ?>