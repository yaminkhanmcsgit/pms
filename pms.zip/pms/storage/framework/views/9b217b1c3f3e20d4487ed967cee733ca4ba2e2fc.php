<footer class="footer text-center">
    <p>&copy; <?php echo e(date('Y')); ?> Progress Management System</p>
</footer>
<?php /**PATH C:\xampp\htdocs\pms\resources\views/layouts/footer.blade.php ENDPATH**/ ?>