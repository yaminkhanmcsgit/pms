


<?php $__env->startSection('title', 'صارفین'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" dir="rtl">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="<?php echo e(route('operators.create')); ?>" class="btn btn-success">
            <i class="fa fa-plus"></i> صارف شامل کریں
        </a>
    </div>
    <center><legend> <h3>صارفین کی فہرست</h3></legend></center>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="thead-dark text-center">
                <tr>
                    <th>نمبر شمار</th>
                    <th>صارف نام</th>
                    <th>مکمل نام</th>
                    <th>ضلع</th>
                    <th>تحصیل</th>
                    <th>رول</th>
                    <th>تاریخ شمولیت</th>
                    <th class="no-print">عمل</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($op->id); ?></td>
                    <td><?php echo e($op->username); ?></td>
                    <td><?php echo e($op->full_name); ?></td>
                    <td><?php echo e($op->district_name); ?></td>
                    <td><?php echo e($op->tehsil_name); ?></td>
                    <td><?php echo e($op->role_title); ?></td>
                    <td><?php echo e($op->created_at ? date('d-m-Y', strtotime($op->created_at)) : ''); ?></td>
                    <td>
                        <a href="<?php echo e(route('operators.edit', $op->id)); ?>" class="btn btn-sm btn-warning">ترمیم</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms\resources\views/operators/index.blade.php ENDPATH**/ ?>