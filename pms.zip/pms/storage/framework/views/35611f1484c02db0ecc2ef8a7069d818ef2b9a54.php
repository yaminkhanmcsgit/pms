

<?php $__env->startSection('title', 'تکمیلی عمل ترمیم کریں'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" dir="rtl">
    <center><legend><h3>تکمیلی عمل ترمیم کریں</h3></legend></center>
    <form action="<?php echo e(route('completion_process.update', $completion_process->id)); ?>" method="POST" class="form-modern">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="form-group col-md-4 col-xs-12">
                <label>ضلع</label>
                <?php if($role_id == 1): ?>
                <select name="zila_id" id="zila_id" class="form-control" required onchange="onDistrictChange(this.value, 'tehsil_id', '<?php echo e($completion_process->tehsil_id); ?>')" data-selected="<?php echo e($completion_process->zila_id); ?>">
                    <option value="">منتخب کریں</option>
                    <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($district->districtId); ?>" <?php if($completion_process->zila_id == $district->districtId): ?> selected <?php endif; ?>><?php echo e($district->districtNameUrdu); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php else: ?>
                <input type="hidden" name="zila_id" value="<?php echo e($districts->first()->districtId); ?>">
                <input type="text" class="form-control" value="<?php echo e($districts->first()->districtNameUrdu); ?>" disabled>
                <?php endif; ?>
            </div>
            <div class="form-group col-md-4 col-xs-12">
                <label>تحصیل</label>
                <?php if($role_id == 1): ?>
                <select name="tehsil_id" id="tehsil_id" class="form-control" required onchange="onTehsilChange(this.value, 'moza_id', '<?php echo e($completion_process->moza_id); ?>')" data-selected="<?php echo e($completion_process->tehsil_id); ?>">
                    <option value="">منتخب کریں</option>
                    <?php $__currentLoopData = $tehsils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tehsil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tehsil->tehsilId); ?>" <?php if($completion_process->tehsil_id == $tehsil->tehsilId): ?> selected <?php endif; ?>><?php echo e($tehsil->tehsilNameUrdu); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php else: ?>
                <input type="hidden" name="tehsil_id" value="<?php echo e($tehsils->first()->tehsilId); ?>">
                <input type="text" class="form-control" value="<?php echo e($tehsils->first()->tehsilNameUrdu); ?>" readonly>
                <?php endif; ?>
            </div>
            <div class="form-group col-md-4 col-xs-12">
                <label>موضع</label>
                <?php if($role_id == 1): ?>
                <select name="moza_id" id="moza_id" class="form-control" required data-selected="<?php echo e($completion_process->moza_id); ?>">
                    <option value="">منتخب کریں</option>
                </select>
                <?php else: ?>
                <select name="moza_id" id="moza_id" class="form-control" required>
                    <option value="">منتخب کریں</option>
                    <?php $__currentLoopData = $mozas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($moza->mozaId); ?>" <?php if($completion_process->moza_id == $moza->mozaId): ?> selected <?php endif; ?>><?php echo e($moza->mozaNameUrdu); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-4 col-xs-12">
                <label>اہلکار</label>
                <select name="employee_id" class="form-control" required>
                    <option value="">منتخب کریں</option>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($emp->id); ?>" <?php if($completion_process->employee_id == $emp->id): ?> selected <?php endif; ?>><?php echo e($emp->nam); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-4 col-xs-12">
                <label>ٹاسک کی قسم</label>
                <select name="completion_process_type_id" id="completion_process_type_id" class="form-control" required>
                    <option value="">منتخب کریں</option>
                    <?php $__currentLoopData = $completion_process_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>" <?php if(($completion_process->completion_process_type_id ?? null) == $type->id): ?> selected <?php endif; ?>><?php echo e($type->title_ur); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-4 col-xs-12">
                <label>نمبر</label>
                <input type="number" name="type_value" class="form-control" value="<?php echo e($completion_process->type_value ?? ''); ?>" placeholder="نمبر درج کریں">
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-4 col-xs-12">
                <label>تاریخ</label>
                <input type="date" name="tareekh" class="form-control" value="<?php echo e($completion_process->tareekh); ?>">
            </div>
        </div>
        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> محفوظ کریں</button>
        <a href="<?php echo e(route('completion_process.index')); ?>" class="btn btn-secondary">واپس</a>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms\resources\views/completion_process/edit.blade.php ENDPATH**/ ?>