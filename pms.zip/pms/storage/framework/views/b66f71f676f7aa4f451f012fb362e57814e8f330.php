

<?php $__env->startSection('title', 'صارف ترمیم کریں'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" dir="rtl">
    <center><legend><h3>صارف ترمیم کریں</h3></legend></center>
    <form action="<?php echo e(route('operators.update', $operator->id)); ?>" method="POST" class="form-modern">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="form-group col-md-4 col-12">
                <label>مکمل نام</label>
                <input type="text" name="full_name" class="form-control" value="<?php echo e($operator->full_name); ?>" required>
            </div>
            <div class="form-group col-md-4 col-12">
                <label>صارف نام</label>
                <input type="text" name="username" class="form-control" value="<?php echo e($operator->username); ?>" required>
            </div>
            <div class="form-group col-md-4 col-12">
                <label>پاس ورڈ (خالی چھوڑیں تو موجودہ رہے گا)</label>
                <input type="password" name="password" class="form-control">
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-6 col-12">
                <label>ضلع</label>
                <select name="zila_id" id="zila_id" class="form-control" required onchange="onDistrictChange(this.value, 'tehsil_id', '<?php echo e($operator->tehsil_id); ?>')" data-selected="<?php echo e($operator->zila_id); ?>">
                    <option value="">منتخب کریں</option>
                </select>
            </div>
            <div class="form-group col-md-6 col-12">
                <label>تحصیل</label>
                <select name="tehsil_id" id="tehsil_id" class="form-control" required onchange="onTehsilChange(this.value, '', '')" data-selected="<?php echo e($operator->tehsil_id); ?>">
                    <option value="">منتخب کریں</option>
                </select>
            </div>
        </div>
        <div class="row">
           
            <div class="form-group col-md-6 col-xs-12">
                <label class="control-label" style="float: right; text-align: right;">رول</label>
                <select name="role_id" class="form-control" style="direction: rtl; text-align: right;">
                    <option value="">منتخب کریں</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->role_id); ?>" <?php if($operator->role_id == $role->role_id): ?> selected <?php endif; ?>><?php echo e($role->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <br>
        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> محفوظ کریں</button>
        <a href="<?php echo e(route('operators.index')); ?>" class="btn btn-secondary">واپس</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms\resources\views/operators/edit.blade.php ENDPATH**/ ?>