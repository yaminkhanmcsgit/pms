<?php 

use App\Http\Controllers\AuthController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\OperatorController;
use App\Http\Controllers\CompletionProcessController;
use App\Http\Controllers\PartalController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\SettingController;

// Auth routes
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
Route::post('/change-password', [AuthController::class, 'changePassword'])->middleware('operator');

// Dashboard (protected by operator session)
Route::get('/dashboard', [HomeController::class, 'index'])->name('dashboard')->middleware('operator');

// Employees
Route::get('/employees', [EmployeeController::class, 'index'])->name('employees.index');
Route::get('/employees/create', [EmployeeController::class, 'create'])->name('employees.create');
Route::post('/employees', [EmployeeController::class, 'store'])->name('employees.store');
Route::get('/employees/{id}/edit', [EmployeeController::class, 'edit'])->name('employees.edit');
Route::put('/employees/{id}', [EmployeeController::class, 'update'])->name('employees.update');

// Operators
Route::get('/operators', [OperatorController::class, 'index'])->name('operators.index');
Route::get('/operators/create', [OperatorController::class, 'create'])->name('operators.create');
Route::post('/operators', [OperatorController::class, 'store'])->name('operators.store');
Route::get('/operators/{id}/edit', [OperatorController::class, 'edit'])->name('operators.edit');
Route::put('/operators/{id}', [OperatorController::class, 'update'])->name('operators.update');

// Completion Process
Route::get('/completion-process', [CompletionProcessController::class, 'index'])->name('completion_process.index');
Route::get('/completion-process/create', [CompletionProcessController::class, 'create'])->name('completion_process.create');
Route::post('/completion-process', [CompletionProcessController::class, 'store'])->name('completion_process.store');
Route::get('/completion-process/{id}/edit', [CompletionProcessController::class, 'edit'])->name('completion_process.edit');
Route::put('/completion-process/{id}', [CompletionProcessController::class, 'update'])->name('completion_process.update');

// Partal
Route::get('/partal', [PartalController::class, 'index'])->name('partal.index');
Route::get('/partal/create', [PartalController::class, 'create'])->name('partal.create');
Route::post('/partal', [PartalController::class, 'store'])->name('partal.store');
Route::get('/partal/{id}/edit', [PartalController::class, 'edit'])->name('partal.edit');
Route::put('/partal/{id}', [PartalController::class, 'update'])->name('partal.update');

// Settings
Route::get('/settings', [SettingController::class, 'edit'])->name('settings.edit');
Route::post('/settings', [SettingController::class, 'update'])->name('settings.update');
